# Security Policy

## Reporting a Vulnerability

Please report (suspected) security vulnerabilities to https://tngconsulting.ca/contact.
