<?php
$string['pluginname'] = '[Molab] Contact Area';
$string['molab_contact_area'] = '[Molab] Contact Area';
$string['blocksettings'] = '[Molab] Contact Block Settings';
$string['molab_contact_area:addinstance'] = 'Add a new [Molab] Contact Area block';
$string['molab_contact_area:myaddinstance'] = 'Add a new [Molab] Contact Area block';