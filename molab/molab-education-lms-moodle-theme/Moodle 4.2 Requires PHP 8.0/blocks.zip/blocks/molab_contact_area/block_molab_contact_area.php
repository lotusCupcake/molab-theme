<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_contact_area extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_contact_area');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->title    = 'Ready to Get Started?';
            $this->config->content  = '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2347.054594094216!2d-1.1282696840056767!3d53.96629823579383!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4879313994d79e01%3A0xcd0ecd5e32a7bd5a!2sBoroughbridge%20Rd%2C%20York%2C%20UK!5e0!3m2!1sen!2sbd!4v1633841282102!5m2!1sen!2sbd"></iframe>';

            $this->config->features_title1          = 'Our Address';
            $this->config->icon1                    = 'ri-map-pin-fill';
            $this->config->features_content1        = '07 Boroughbridge Road BISLEY GL6 5PA';

            $this->config->features_title2          = 'Contact';
            $this->config->icon2                    = 'ri-phone-fill';
            $this->config->features_content2        = '<a href="tel:+1(135)-1984-2020">+1(135) 1984 2020</a><a href="tel:+1(135)-1207-0507">+1(135) 1207 0507</a>';

            $this->config->features_title3          = 'Email';
            $this->config->icon3                    = 'ri-mail-fill';
            $this->config->features_content3        = '<a href="mailto:hello@molab.com">hello@molab.com</a>
            <a href="mailto:info@molab.com">info@molab.com</a>';

            $this->config->features_title4          = 'Hours of Operation';
            $this->config->icon4                    = 'ri-time-fill';
            $this->config->features_content4        = '(8 AM - 7 PM, Monday - Friday)';
        }
    }

    public function get_content() {
        global $CFG, $DB;

        $this->content         =  new stdClass;

        $features_number = 4;
        if(isset($this->config->features_number)){
            $features_number = $this->config->features_number;
        }

        $text = '';
        $text .='
        <div class="contact-info-area pt-100 pb-70">
			<div class="container">
				<div class="row">
					<div class="col-lg-4">
						<div class="contact-info-content">
							<h2>'.$this->config->title.'</h2>

							<ul>';
                            for($i = 1; $i <= $features_number; $i++) {
                                $icon                   = 'icon' . $i;
                                $features_title         = 'features_title' . $i;
                                $features_content       = 'features_content' . $i;
        
                                // Title
                                if(isset($this->config->$features_title)) { $features_title = $this->config->$features_title; }else{ $features_title = ''; }
        
                                if(isset($this->config->$icon)) { $icon = $this->config->$icon; }else{ $icon = ''; }
        
                                // Content
                                if(isset($this->config->$features_content)) { $features_content = $this->config->$features_content; }else{ $features_content = ''; }
        
                                $text .= '
                                    <li>';
                                        if($icon):
                                            $text .= '
                                            <i class="'.$icon.'"></i>';
                                        endif;
                                        $text .= '
                                        <h3>'.$features_title.'</h3>
                                        '.$features_content.'
                                    </li>';
                            } $text .= '
							</ul>
						</div>
					</div>

					<div class="col-lg-8">
						<div class="maps">
							'.$this->config->content.'
						</div>
					</div>
				</div>
			</div>
		</div>
        
        ';
        if($this->config->title || $this->config->contact_from_code):
            $text .= '
            <div class="contact-area pb-100">
                <div class="container">
                    <div class="section-title">
                        <h2>'.$this->config->title.'</h2>
                    </div>
                    
                    <div class="contact-form main-contact-form">
                        '.$this->config->contact_from_code.'
                    </div>
                </div>
            </div>';
        endif;
        
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}