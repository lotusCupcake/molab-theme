<?php

class block_molab_contact_area_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;
        $molabFontList = include($CFG->dirroot . '/theme/molab/inc/font_handler/molab_font_select.php');

        $features_number = 4;
        if(isset($this->block->config->features_number)){
            $features_number = $this->block->config->features_number;
        }

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        //  Content
        $mform->addElement('textarea', 'config_content', 'Content');
        $mform->setDefault('config_quote_content', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2347.054594094216!2d-1.1282696840056767!3d53.96629823579383!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4879313994d79e01%3A0xcd0ecd5e32a7bd5a!2sBoroughbridge%20Rd%2C%20York%2C%20UK!5e0!3m2!1sen!2sbd!4v1633841282102!5m2!1sen!2sbd"></iframe>');
        $mform->setType('config_quote_content', PARAM_RAW);

        // Title
        $mform->addElement('text', 'config_title', 'Form Title');
        $mform->setDefault('config_title', 'Ready to Get Started?');
        $mform->setType('config_title', PARAM_RAW);

        $mform->addElement('textarea', 'config_contact_from_code', 'Form Code', 'wrap="virtual" rows="10" cols="50"');

        $mform->addElement('static', 'config_cotact_doc', '<b><a style="color: var(--main-color)" href="https://moodle.org/plugins/local_contact" target="_blank">Please make sure Contact Form plugin is installed.</a></b>'); 

        $featuresrange = array(
            1 => '1',
            2 => '2',
            3 => '3',
            4 => '4',
            5 => '5',
            6 => '6',
            7 => '7',
            8 => '8',
            9 => '9',
            10 => '10',
            11 => '11',
            12 => '12',
            13 => '13',
            14 => '14',
            15 => '15',
            16 => '16',
            17 => '17',
            18 => '18',
            19 => '19',
            20 => '20',
            21 => '21',
            22 => '22',
            23 => '23',
            24 => '24',
            25 => '25',
            26 => '26',
            27 => '27',
            28 => '28',
            29 => '29',
            30 => '30',
        );

        $mform->addElement('select', 'config_features_number', get_string('config_items', 'theme_molab'), $featuresrange);
        $mform->setDefault('config_features_number', 4);

        for($i = 1; $i <= $features_number; $i++) {
            $mform->addElement('header', 'config_molab_item' . $i , get_string('config_item', 'theme_molab') . $i);

            // Search Icon
            $select = $mform->addElement('select', 'config_icon', 'Icon', $molabFontList, array('class'=>'molab_icon_class'));
            $select->setSelected('ri-map-pin-fill');

            // Title
            $mform->addElement('text', 'config_features_title' . $i, get_string('config_title', 'theme_molab', $i));
            $mform->setDefault('config_features_title' . $i, 'Our Address');
            $mform->setType('config_features_title' . $i, PARAM_TEXT);

            // Content
            $mform->addElement('textarea', 'config_features_content' . $i, get_string('config_content', 'theme_molab', $i));
            $mform->setDefault('config_features_content' . $i, '07 Boroughbridge Road BISLEY GL6 5PA');
            $mform->setType('config_features_content' . $i, PARAM_TEXT);
        }
    }
}
