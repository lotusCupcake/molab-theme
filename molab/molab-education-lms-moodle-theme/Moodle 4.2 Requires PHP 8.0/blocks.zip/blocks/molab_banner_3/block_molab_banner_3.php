<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');

class block_molab_banner_3 extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_banner_3');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');

        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->top_title = 'FOR A BETTER FUTURE';
            $this->config->title = 'Make Your Dream Come True With Our Course';
            $this->config->search_placeholder = 'What do you want to learn?';
            $this->config->placeholder_icon = 'ri-search-line';
            $this->config->partner_title = 'Join Businesses Around The World Who Believe In <span>Molab</span>';
 
            $this->config->logo = $CFG->wwwroot .'/theme/molab/pix/logo.svg';
            $this->config->shape_image = $CFG->wwwroot .'/theme/molab/pix/banner/banner-shape-img-1.webp';
            $this->config->shape_image2 = $CFG->wwwroot .'/theme/molab/pix/banner/banner-shape-img-2.webp';
        }
    }

    public function get_content() {
        global $CFG, $DB;
        require_once($CFG->libdir . '/filelib.php');

        if ($this->content !== null) {
          return $this->content;
        }

        $this->content  =  new stdClass;

        if (\core_search\manager::is_global_search_enabled() === false) {
            $this->content->search_placeholder = 'Global searching is not enabled.';
        }else{
            if(isset($this->config->search_placeholder) && !empty($this->config->search_placeholder)){
                $this->content->search_placeholder = $this->config->search_placeholder;
            }else{
                $this->content->search_placeholder = '';
            }
        }
        $url = new moodle_url('/search/index.php');

        $text = '';
        $text .= '
        <div class="banner-area bg-3">
			<div class="d-table">
				<div class="d-table-cell">
					<div class="container">
						<div class="banner-content style-three">';
                            if($this->config->logo):
                                $text .= '
                                <a href="'.$CFG->wwwroot.'/?redirect=0">
                                    <img src="'.molab_block_image_process($this->config->logo).'" alt="'.$this->config->title.'">
                                </a>';
                            endif;
                            $text .= '
                            
							<span class="top-title">'.$this->config->top_title.'</span>
							<h1>'.$this->config->title.'</h1>

							<div class="search-bar">';
                                if($this->content->search_placeholder):
                                    $text .= '
                                    <form action="'.$url->out().'">
                                        <input class="form-control" type="search" name="q" placeholder="'.$this->content->search_placeholder.'" aria-label="Search">';
                                        if($this->config->placeholder_icon):
                                            $text .= '
                                            <button class="btn search-btn" type="submit">
                                                <i class="'.$this->config->placeholder_icon.'"></i>
                                            </button>';
                                        endif;
                                        $text .= '
                                    </form>';
                                endif;
                                $text .= '
							</div>
						</div>
					</div>
				</div>
			</div>';

            if($this->config->shape_image):
                $text .= '
                <div class="shape banner-shape-img-1" data-speed="0.09" data-revert="true">
                    <img src="'.molab_block_image_process($this->config->shape_image).'" alt="'.$this->config->title.'">
                </div>';
            endif;

            if($this->config->shape_image2):
                $text .= '
                <div class="shape banner-shape-img-2" data-speed="0.09" data-revert="true">
                    <img src="'.molab_block_image_process($this->config->shape_image2).'" alt="'.$this->config->title.'">
                </div>';
            endif;
            $text .= '
		</div>
        
        ';
        if($this->config->partner_title):
            $text .= '
            <div class="partner-area style-three pb-50 bg-color-f5f1ee">
                <div class="container">
                    <div class="section-title">
                        <p>'.$this->config->partner_title.'</p>
                    </div>

                    <div class="partner-slider owl-carousel owl-theme">';
                        $fs     = get_file_storage();
                        $files  = $fs->get_area_files($this->context->id, 'block_molab_banner_3', 'content');
                        foreach ($files as $file) {
                            $filename = $file->get_filename();
                            if ($filename <> '.') {
                                $url = moodle_url::make_pluginfile_url($file->get_contextid(), $file->get_component(), $file->get_filearea(), null, $file->get_filepath(), $filename);
                                $text .= '
                                <div class="partner-item">
                                    <img src="'. $url.'" alt="'. $filename.'">
                                </div>';
                            }
                        } $text .= '
                    </div>
                </div>
            </div>';
        endif;
        
        $this->content         =  new stdClass;
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}