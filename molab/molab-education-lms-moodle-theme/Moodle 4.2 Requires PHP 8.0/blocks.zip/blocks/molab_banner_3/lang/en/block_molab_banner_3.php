<?php
$string['pluginname'] = '[Molab] Banner Three';
$string['molab_banner_3'] = '[Molab] Banner Three';
$string['molab_banner_3:addinstance'] = 'Add a new [Molab] Banner block';
$string['molab_banner_3:myaddinstance'] = 'Add a new [Molab] Banner style 3 block';
$string['config_search_btn'] = 'Search Button Text';
$string['config_search_placeholder'] = 'Search Placeholder(Leave this blank if you want to hide the search field!)';
$string['config_placeholder_icon'] = 'Search Placeholder Icon';
$string['config_bottom_title'] = 'Banner Bottom Content';