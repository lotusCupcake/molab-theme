<?php

class block_molab_banner_3_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;
        $molabFontList = include($CFG->dirroot . '/theme/molab/inc/font_handler/molab_font_select.php');

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        // Top Title
        $mform->addElement('text', 'config_top_title', 'Banner Top Title');
        $mform->setDefault('config_top_title', 'FOR A BETTER FUTURE');
        $mform->setType('config_top_title', PARAM_RAW);

        // Title
        $mform->addElement('text', 'config_title', 'Banner Title');
        $mform->setDefault('config_title', 'Make Your Dream Come True With Our Course');
        $mform->setType('config_title', PARAM_RAW);

        // Search Placeholder Text
        $mform->addElement('text', 'config_search_placeholder', get_string('config_search_placeholder', 'block_molab_banner_3'));
        $mform->setDefault('config_search_placeholder', 'What do you want to learn?');
        $mform->setType('config_search_placeholder', PARAM_RAW);

        // Search Field Icon
        $select = $mform->addElement('select', 'config_placeholder_icon', 'Search Button Icon', $molabFontList, array('class'=>'molab_icon_class'));
        $select->setSelected('ri-search-line');

        // Partner Title
        $mform->addElement('text', 'config_partner_title', 'Partner Title');
        $mform->setDefault('config_partner_title', 'Join Businesses Around The World Who Believe In <span>Molab</span>');
        $mform->setType('config_partner_title', PARAM_RAW);

        // Section Image header title according to language file.
        $mform->addElement('header', 'config_image_heading', get_string('config_image_heading', 'theme_molab'));

        $mform->addElement('static', 'config_image_doc', '<b><a style="color: var(--main-color)" href="https://docs.envytheme.com/docs/molab-moodle-theme-documentation/faqs/how-to-get-the-image-url/" target="_blank">Doc link: How to make Image URL?</a></b>'); 

        // Banner Logo
        $mform->addElement('text', 'config_logo', 'Banner Logo URL');
        $mform->setDefault('config_logo', $CFG->wwwroot .'/theme/molab/pix/logo.svg');
        $mform->setType('config_logo', PARAM_TEXT);

        // Banner Shape Image 1
        $mform->addElement('text', 'config_shape_image', 'Banner Shape Image 1 URL');
        $mform->setDefault('config_shape_image', $CFG->wwwroot .'/theme/molab/pix/banner/banner-shape-img-1.webp');
        $mform->setType('config_shape_image', PARAM_TEXT);

        // Banner Shape Image 2
        $mform->addElement('text', 'config_shape_image2', 'Banner Shape Image 1 URL');
        $mform->setDefault('config_shape_image2', $CFG->wwwroot .'/theme/molab/pix/banner/banner-shape-img-2.webp');
        $mform->setType('config_shape_image2', PARAM_TEXT);

        // Image
        $mform->addElement('filemanager', 'config_image', 'Partner Images', null,
                array('subdirs' => 0, 'maxbytes' => 10485760, 'areamaxbytes' => 10485760, 'maxfiles' => null ));
    }

    function set_data($defaults)
    {
        // Begin Image Processing
        if (empty($entry->id)) {
            $entry = new stdClass;
            $entry->id = null;
        }
        $draftitemid = file_get_submitted_draft_itemid('config_image');
        file_prepare_draft_area($draftitemid, $this->block->context->id, 'block_molab_banner_3', 'content', 0,
            array('subdirs' => true));
        $entry->attachments = $draftitemid;
        parent::set_data($defaults);
        if ($data = parent::get_data()) {
            file_save_draft_area_files($data->config_image, $this->block->context->id, 'block_molab_banner_3', 'content', 0,
                array('subdirs' => true));
        }
        // END Image Processing
    }
}
