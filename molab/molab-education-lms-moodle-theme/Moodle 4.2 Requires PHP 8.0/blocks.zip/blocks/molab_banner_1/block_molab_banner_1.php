<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');

class block_molab_banner_1 extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_banner_1');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');

        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->top_title = 'FOR A BETTER FUTURE';
            $this->config->title = 'We Have All Kinds Of <span>Courses</span> Collection';
            $this->config->body = 'The experience of our instructors benefits your career';
            $this->config->bottom_title = '<h6>New additions courses published each month</h6><p>Choose from <span>25,000 +</span> online video courses</p>';
            $this->config->placeholder_icon = 'ri-search-line';
            $this->config->link_title = 'Popular Courses:';
            $this->config->link_content = '<a href="#">Design</a>
            <a href="#">Development</a>
            <a href="#">Marketing</a>
            <a href="#">Music</a>';
            $this->config->banner_bg_img = $CFG->wwwroot .'/theme/molab/pix/banner/banner-bg.webp';
            $this->config->banner_img = $CFG->wwwroot .'/theme/molab/pix/banner/banner-img.webp';
            $this->config->bottom_content_img = $CFG->wwwroot .'/theme/molab/pix/new-additions.webp';
            $this->config->shape_image = $CFG->wwwroot .'/theme/molab/pix/banner/banner-shap-left.svg';
        }
    }

    public function get_content() {
        global $CFG, $DB;

        if ($this->content !== null) {
          return $this->content;
        }

        $this->content  =  new stdClass;

        if (\core_search\manager::is_global_search_enabled() === false) {
            $this->content->search_placeholder = 'Global searching is not enabled.';
        }else{
            if(isset($this->config->search_placeholder) && !empty($this->config->search_placeholder)){
                $this->content->search_placeholder = $this->config->search_placeholder;
            }else{
                $this->content->search_placeholder = '';
            }
        }
        $url = new moodle_url('/search/index.php');


        $text = '';
        $text .= '
        <div class="banner-area bg-1" style="background-image:url('.$this->config->banner_bg_img.');">
			<div class="d-table">
				<div class="d-table-cell">
					<div class="container-fluid">
						<div class="row align-items-center">
							<div class="col-lg-6">
								<div class="banner-content">
									<span class="top-title">'.$this->config->top_title.'</span>
									<h1>'.$this->config->title.'</h1>
									<p>'.$this->config->body.'</p>
		
									<div class="search-bar">';
                                        if($this->content->search_placeholder):
                                            $text .= '
                                            <form action="'.$url->out().'">
                                                <input class="form-control" type="search" name="q" placeholder="'.$this->content->search_placeholder.'" aria-label="Search">';
                                                if($this->config->placeholder_icon):
                                                    $text .= '
                                                    <button class="btn search-btn" type="submit">
                                                        <i class="'.$this->config->placeholder_icon.'"></i>
                                                    </button>';
                                                endif;
                                                $text .= '
                                            </form>';
                                        endif;
                                        $text .= '
									</div>
		
									<ul class="popular-courses-tag">
										<li>
											<span>'.$this->config->link_title.'</span>
										</li>
										<li>
                                            '.$this->config->link_content.'
										</li>
									</ul>
								</div>
							</div>

							<div class="col-lg-6">
								<div class="banner-img main-img" data-speed="0.09" data-revert="true">';
                                    if($this->config->banner_img):
                                        $text .= '
                                        <img src="'.molab_block_image_process($this->config->banner_img).'" alt="'.$this->config->title.'">';
                                    endif;
                                    $text .= '
								</div>
							</div>
						</div>
						<div class="new-additions-content">
							<div class="new-additions" data-speed="0.09" data-revert="true">';
                                if($this->config->bottom_content_img):
                                    $text .= '
                                    <div class="new-brand">
                                        <img src="'.molab_block_image_process($this->config->bottom_content_img).'" alt="'.$this->config->title.'">
                                    </div>';
                                endif;
                                $text .= '
								
                                '.$this->config->bottom_title.'
							</div>
						</div>
					</div>
				</div>
			</div>

            ';
            if($this->config->shape_image):
                $text .= '
                <div class="banner-shape-left" data-speed="0.09" data-revert="true">
                    <img src="'.molab_block_image_process($this->config->shape_image).'" alt="'.$this->config->title.'">
                </div>';
            endif;
            $text .= '
		</div>';
        
        $this->content         =  new stdClass;
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}