<?php
$string['pluginname'] = '[Molab] Banner One';
$string['molab_banner_1'] = '[Molab] Banner One';
$string['molab_banner_1:addinstance'] = 'Add a new [Molab] Banner block';
$string['molab_banner_1:myaddinstance'] = 'Add a new [Molab] Banner style 1 block';
$string['config_search_btn'] = 'Search Button Text';
$string['config_search_placeholder'] = 'Search Placeholder(Leave this blank if you want to hide the search field!)';
$string['config_placeholder_icon'] = 'Search Placeholder Icon';
$string['config_bottom_title'] = 'Banner Bottom Content';