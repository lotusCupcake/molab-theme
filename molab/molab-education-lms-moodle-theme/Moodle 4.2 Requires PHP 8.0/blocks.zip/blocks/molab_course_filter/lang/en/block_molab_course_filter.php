<?php
$string['pluginname'] = '[Molab] Course Filter';
$string['molab_course_filter'] = '[Molab] Course Filter';
$string['blocksettings'] = '[Molab] Course Filter Block Settings';
$string['molab_course_filter:addinstance'] = 'Add a new [Molab] Course Filter block';
$string['molab_course_filter:myaddinstance'] = 'Add a new [Molab] Course Filter block';
$string['molab_course_filter'] = '[Molab] Course Filter';