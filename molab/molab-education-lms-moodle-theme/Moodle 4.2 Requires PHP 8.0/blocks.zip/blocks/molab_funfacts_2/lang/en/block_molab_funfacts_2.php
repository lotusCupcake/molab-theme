<?php
$string['pluginname'] = '[Molab] Funfacts Two';
$string['molab_funfacts_2'] = '[Molab] Funfacts Two';
$string['blocksettings'] = '[Molab] Funfacts Two Block Settings';
$string['molab_funfacts_2:addinstance'] = 'Add a new [Molab] Funfacts Two block';
$string['molab_funfacts_2:myaddinstance'] = 'Add a new [Molab] Funfacts Two block';