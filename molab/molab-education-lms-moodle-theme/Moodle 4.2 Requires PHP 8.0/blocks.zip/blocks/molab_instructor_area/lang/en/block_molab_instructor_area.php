<?php
$string['pluginname'] = '[Molab] Instructor Area';
$string['molab_instructor_area'] = '[Molab] Instructor Area';
$string['blocksettings'] = '[Molab] Instructor Area Block Settings';
$string['molab_instructor_area:addinstance'] = 'Add a new [Molab] Instructor Area block';
$string['molab_instructor_area:myaddinstance'] = 'Add a new [Molab] Instructor Area block';
$string['config_instructor_name'] = 'Name';
$string['config_instructor_img'] = 'Image URL';
$string['config_instructor_designation'] = 'Designation';
$string['config_social_link'] = 'Social Link';