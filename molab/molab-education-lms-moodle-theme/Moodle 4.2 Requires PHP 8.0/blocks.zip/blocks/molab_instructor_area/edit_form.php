<?php

class block_molab_instructor_area_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;
        $molabFontList = include($CFG->dirroot . '/theme/molab/inc/font_handler/molab_font_select.php');

        $itemNumber = 4;
        if(isset($this->block->config->itemNumber)){
            $itemNumber = $this->block->config->itemNumber;
        }

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        $mform->addElement('select', 'config_style', get_string('config_style', 'theme_molab'), array(1 => 'Style 1', 2 => 'Style 2', 3 => 'Style 3'));
        $mform->setDefault('config_style', 1);
        
        // Title
        $mform->addElement('text', 'config_title', get_string('config_title', 'theme_molab'));
        $mform->setDefault('config_title', 'These Are Our Instructor​');
        $mform->setType('config_title', PARAM_RAW);

        // Content
        $mform->addElement('textarea', 'config_body', get_string('config_body', 'theme_molab'), 'wrap="virtual" rows="6" cols="50"');
        $mform->setDefault('config_body', '<p>Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p><p>Proin eget tortor risus. Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Mauris blandit aliquet elit, egettincidunt nibh pulvinar ultricies ligula sed magna dictum porta.</p>');
        $mform->setType('config_body', PARAM_RAW);

        // Button Text
        $mform->addElement('text', 'config_btn', 'Button Text');
        $mform->setDefault('config_btn', 'View All Instructors​');
        $mform->setType('config_btn', PARAM_RAW);

        // Button Link
        $mform->addElement('text', 'config_link', 'Button Link');
        $mform->setDefault('config_link', '#​');
        $mform->setType('config_link', PARAM_RAW);

        // Shape Image 
        $mform->addElement('text', 'config_shape_img', 'Shape Image 1 URL');
        $mform->setDefault('config_shape_img', $CFG->wwwroot .'/theme/molab/pix/instructors/instructors-shape-1.png');
        $mform->setType('config_shape_img', PARAM_TEXT);

        // Shape Image 2
        $mform->addElement('text', 'config_shape_img2', 'Shape Image 2 URL');
        $mform->setDefault('config_shape_img2', $CFG->wwwroot .'/theme/molab/pix/instructors/instructors-shape-2.png');
        $mform->setType('config_shape_img2', PARAM_TEXT);

        $range = array(
            1 => '1',
            2 => '2',
            3 => '3',
            4 => '4',
            5 => '5',
            6 => '6',
            7 => '7',
            8 => '8',
            9 => '9',
            10 => '10',
            11 => '11',
            12 => '12',
            13 => '13',
            14 => '14',
            15 => '15',
            16 => '16',
            17 => '17',
            18 => '18',
            19 => '19',
            20 => '20',
            21 => '21',
            22 => '22',
            23 => '23',
            24 => '24',
            25 => '25',
            26 => '26',
            27 => '27',
            28 => '28',
            29 => '29',
            30 => '30',
        );

        $mform->addElement('select', 'config_itemNumber', get_string('config_items', 'theme_molab'), $range);
        $mform->setDefault('config_itemNumber', 4);

        for($i = 1; $i <= $itemNumber; $i++) {
            $mform->addElement('header', 'config_molab_item' . $i , get_string('config_item', 'theme_molab') . $i);

            $mform->addElement('text', 'config_instructor_name' . $i, get_string('config_instructor_name', 'block_molab_instructor_area', $i));
            $mform->setDefault('config_instructor_name' . $i, 'William James');
            $mform->setType('config_instructor_name' . $i, PARAM_TEXT);

            $mform->addElement('text', 'config_instructor_designation' . $i, get_string('config_instructor_designation', 'block_molab_instructor_area', $i));
            $mform->setDefault('config_instructor_designation' . $i, 'Full Stack Developer');
            $mform->setType('config_instructor_designation' . $i, PARAM_TEXT);

            $mform->addElement('text', 'config_instructor_img' . $i, get_string('config_instructor_img', 'block_molab_instructor_area', $i));
            if($i <= 5):
                $mform->setDefault('config_instructor_img' . $i, $CFG->wwwroot.'/theme/molab/pix/instructors/instructors-'.$i.'.webp');
            else:
                $mform->setDefault('config_instructor_img' . $i, $CFG->wwwroot.'/theme/molab/pix/instructors/instructors-1.webp');
            endif;
            $mform->setType('config_instructor_img' . $i, PARAM_TEXT);

            // Social Icon 1
            $select = $mform->addElement('select', 'config_social_1_icon' . $i, get_string('config_icon', 'theme_molab', $i), $molabFontList, array('class'=>'molab_icon_class'));
            $mform->setDefault('config_social_1_icon'.$i, 'bx bxl-facebook');

            $mform->addElement('text', 'config_social_1_link' . $i, get_string('config_social_link', 'block_molab_instructor_area', $i));
            $mform->setDefault('config_social_1_link' . $i, '#');
            $mform->setType('config_social_1_link' . $i, PARAM_TEXT);

            // Social Icon 2
            $select = $mform->addElement('select', 'config_social_2_icon' . $i, get_string('config_icon', 'theme_molab', $i), $molabFontList, array('class'=>'molab_icon_class'));
            $mform->setDefault('config_social_2_icon'.$i, 'bx bxl-twitter');

            $mform->addElement('text', 'config_social_2_link' . $i, get_string('config_social_link', 'block_molab_instructor_area', $i));
            $mform->setDefault('config_social_2_link' . $i, '#');
            $mform->setType('config_social_2_link' . $i, PARAM_TEXT);

            // Social Icon 3
            $select = $mform->addElement('select', 'config_social_3_icon' . $i, get_string('config_icon', 'theme_molab', $i), $molabFontList, array('class'=>'molab_icon_class'));
            $mform->setDefault('config_social_3_icon'.$i, 'bx bxl-instagram');

            $mform->addElement('text', 'config_social_3_link' . $i, get_string('config_social_link', 'block_molab_instructor_area', $i));
            $mform->setDefault('config_social_3_link' . $i, '#');
            $mform->setType('config_social_3_link' . $i, PARAM_TEXT);

            // Social Icon 4
            $select = $mform->addElement('select', 'config_social_4_icon' . $i, get_string('config_icon', 'theme_molab', $i), $molabFontList, array('class'=>'molab_icon_class'));
            $mform->setDefault('config_social_4_icon'.$i, 'bx bxl-linkedin');

            $mform->addElement('text', 'config_social_4_link' . $i, get_string('config_social_link', 'block_molab_instructor_area', $i));
            $mform->setDefault('config_social_4_link' . $i, '#');
            $mform->setType('config_social_4_link' . $i, PARAM_TEXT);

            // Social Icon 5
            $select = $mform->addElement('select', 'config_social_5_icon' . $i, get_string('config_icon', 'theme_molab', $i), $molabFontList, array('class'=>'molab_icon_class'));
            $mform->setDefault('config_social_5_icon'.$i, '');

            $mform->addElement('text', 'config_social_5_link' . $i, get_string('config_social_link', 'block_molab_instructor_area', $i));
            $mform->setDefault('config_social_5_link' . $i, '');
            $mform->setType('config_social_5_link' . $i, PARAM_TEXT);
        }
    }
}
