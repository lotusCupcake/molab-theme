<?php

class block_molab_features_area_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;

        $features_number = 3;
        if(isset($this->block->config->features_number)){
            $features_number = $this->block->config->features_number;
        }

        $style = 1;
        if(isset($this->block->config->style)){
            $style = $this->block->config->style;
        }

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        $mform->addElement('select', 'config_style', get_string('config_style', 'theme_molab'), array(1 => 'Style 1', 2 => 'Style 2'));
        $mform->setDefault('config_style', 1);

        if($style == 2):
            $mform->addElement('text', 'config_left_shape_img', 'Section Left Image(for Style 2)');
            $mform->setDefault('config_left_shape_img', $CFG->wwwroot.'/theme/molab/pix/human-3.webp');
            $mform->setType('config_left_shape_img', PARAM_TEXT);

            $mform->addElement('text', 'config_right_shape_img', 'Section Right Image(for Style 2)');
            $mform->setDefault('config_right_shape_img', $CFG->wwwroot.'/theme/molab/pix/new-additions.webp');
            $mform->setType('config_right_shape_img', PARAM_TEXT);

            // Title
            $mform->addElement('text', 'config_right_title', 'Section Right Title(for Style 2)');
            $mform->setDefault('config_right_title', 'New additions courses published each month');
            $mform->setType('config_right_title', PARAM_TEXT);

            // Content
            $mform->addElement('text', 'config_right_content', 'Section Right Content(for Style 2)');
            $mform->setDefault('config_right_content', 'Choose from <span>25,000 +</span> online video courses');
            $mform->setType('config_right_content', PARAM_TEXT);
        endif;

        $featuresrange = array(
            1 => '1',
            2 => '2',
            3 => '3',
            4 => '4',
            5 => '5',
            6 => '6',
            7 => '7',
            8 => '8',
            9 => '9',
            10 => '10',
            11 => '11',
            12 => '12',
            13 => '13',
            14 => '14',
            15 => '15',
            16 => '16',
            17 => '17',
            18 => '18',
            19 => '19',
            20 => '20',
            21 => '21',
            22 => '22',
            23 => '23',
            24 => '24',
            25 => '25',
            26 => '26',
            27 => '27',
            28 => '28',
            29 => '29',
            30 => '30',
        );

        $mform->addElement('select', 'config_features_number', get_string('config_items', 'theme_molab'), $featuresrange);
        $mform->setDefault('config_features_number', 3);

        for($i = 1; $i <= $features_number; $i++) {
            $mform->addElement('header', 'config_molab_item' . $i , get_string('config_item', 'theme_molab') . $i);

            // Image URL
            $mform->addElement('static', 'config_image_doc' . $i, '<b><a style="color: var(--main-color)" href="https://docs.envytheme.com/docs/molab-moodle-theme-documentation/faqs/how-to-get-the-image-url/" target="_blank">Doc link: How to make Image URL?</a></b>'); 

            $mform->addElement('text', 'config_img' . $i, 'Feature Icon' . $i);
            if($i <= 4):
                $mform->setDefault('config_img' . $i, $CFG->wwwroot.'/theme/molab/pix/features/icon'.$i.'.webp');
            else:
                $mform->setDefault('config_img' . $i, $CFG->wwwroot.'/theme/molab/pix/features/icon1.webp');
            endif;
            $mform->setType('config_img' . $i, PARAM_TEXT);

            // Title
            $mform->addElement('text', 'config_features_title' . $i, get_string('config_title', 'theme_molab', $i));
            $mform->setDefault('config_features_title' . $i, 'Expedite Learning');
            $mform->setType('config_features_title' . $i, PARAM_TEXT);

            // Card Content
            $mform->addElement('text', 'config_features_content' . $i, get_string('config_content', 'theme_molab', $i));
            $mform->setDefault('config_features_content' . $i, 'Adopting fast learning techniques');
            $mform->setType('config_features_content' . $i, PARAM_TEXT);
        }
    }
}
