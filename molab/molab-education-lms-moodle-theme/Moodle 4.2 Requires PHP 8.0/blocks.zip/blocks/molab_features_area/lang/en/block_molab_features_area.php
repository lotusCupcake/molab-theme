<?php
$string['pluginname'] = '[Molab] Features Area';
$string['molab_features_area'] = '[Molab] Features Area';
$string['blocksettings'] = '[Molab] Features Block Settings';
$string['molab_features_area:addinstance'] = 'Add a new [Molab] Features Area block';
$string['molab_features_area:myaddinstance'] = 'Add a new [Molab] Features Area block';