<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_about_area extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_about_area');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->title = 'We Share Knowledge Among The World';
            $this->config->items = 3;
            $this->config->content = 'Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Proin eget tortor risus. Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Sed porttitor lectus nibh. Donec quis ac lectus. Proin eget tortor risus. Sed porttitor lectus nibh. Praesent sapien massa, convallis risus. Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Sed porttitor lectus nibh. Donec';
            $this->config->quote_content = 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Proin eget tortor risus. Sed porttitor lectus nibh. Praesent sapien massa. Quisque velit nisi, pretium ut lacinia in elementum id enim non nulla sit amet nisl tempus convallis quis ac lectus proin eget.';
            $this->config->name = 'Lance Altman';
            $this->config->designation = 'Founder, CEO';
            $this->config->img = $CFG->wwwroot .'/theme/molab/pix/about-img-2.webp';
            $this->config->shape_img = $CFG->wwwroot .'/theme/molab/pix/quat-s.webp';
            $this->config->shape_img2 =  $CFG->wwwroot .'/theme/molab/pix/about-shape-1.webp';

            $this->config->features_title1 = 'Who we are?';
            $this->config->features_content1 = '<p>Donec rutrum congue leo eget malesuada. Praesent massa, convallis a pellentesque egestas Curabitur , accumsan imperdiet et, porttitor at sem. Cras ultricies ligula sed magna dictum porta.</p>
            <p>Vestibulum ante ipsum primis in faucibus orci luctus ultrices posuere cubilia. Curabitur arcu erat, accumsan imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>';

            $this->config->features_title2 = 'Why choose us?';
            $this->config->features_content2 = '<p>Donec rutrum congue leo eget malesuada. Praesent massa, convallis a pellentesque egestas Curabitur erat, accumsan id imperdiet et.</p>
            <ul>
                <li>Vestibulum ante ipsum primis in faucibus.</li>
                <li>Orci luctus et ultrices posuere cubilia.</li>
                <li> Curabitur arcu accumsan imperdiet porttitor</li>
                <li>Orci luctus et ultrices posuere cubilia.</li>
            </ul>';
            $this->config->features_title3 = 'What we do?';
            $this->config->features_content3 = '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias obcaecati recusandae, commodi excepturi eos</p>';
        }
    }

    public function get_content() {
        global $CFG, $USER, $DB, $OUTPUT;

        if ($this->content !== null) {
            return $this->content;
        }

        if (isset($this->config->items)) {
            $data = $this->config;
            $data->items = is_numeric($data->items) ? (int)$data->items : 3;
        } else {
            $data = new stdClass();
            $data->items = '0';
        }

        $this->content         =  new stdClass;

        $text = '';

        $text .= '
        <div class="about-area style-three ptb-100">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-lg-6">
						<div class="about-bg-2">';
                        if($this->config->img):
                            $text .= '<img src="'.molab_block_image_process($this->config->img).'" alt="'.$this->config->title.'">';
                        endif; 
                        $text .= '
						</div>
					</div>

					<div class="col-lg-6">
						<div class="about-content style-three pl-15">
                            <h2>'.$this->config->title.'</h2>  
                            <p>'.$this->config->content.'</p>
                                
							<div class="quat-style">';
                                if($this->config->shape_img):
                                    $text .= '<img src="'.molab_block_image_process($this->config->shape_img).'" alt="'.$this->config->title.'">';
                                endif; 
                                $text .= '
								<p>'.$this->config->quote_content.'</p>
							</div>

							<div class="author">
								<h3>'.$this->config->name.'</h3>
								<span>'.$this->config->designation.'</span>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="shape about-shape-1 style-three" data-speed="0.09" data-revert="true">';
                if($this->config->shape_img2):
                    $text .= '<img src="'.molab_block_image_process($this->config->shape_img2).'" alt="'.$this->config->title.'">';
                endif; 
                $text .= '
			</div>
		</div>';

        if ($data->items > 0) {
            $text .= '
            <div class="feature-area pb-70">
                <div class="container">
                    <div class="row justify-content-center">';
                        for ($i = 1; $i <= $data->items; $i++) {
                            $features_title         = 'features_title' . $i;
                            $features_content       = 'features_content' . $i;

                            // Title
                            if(isset($this->config->$features_title)) { $features_title = $this->config->$features_title; }else{ $features_title = ''; }

                            // Content
                            if(isset($this->config->$features_content)) { $features_content = $this->config->$features_content; }else{ $features_content = ''; }

                            $text .= '
                            <div class="col-lg-4 col-md-6">
                                <div class="single-about-feature">
                                    <h3>'.$features_title.'</h3>
                                    '.$features_content.'
                                </div>
                            </div>';
                        }
                        $text .= '
                    </div>
                </div>
            </div>';
        }

        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    function instance_allow_config() {
        return true;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}