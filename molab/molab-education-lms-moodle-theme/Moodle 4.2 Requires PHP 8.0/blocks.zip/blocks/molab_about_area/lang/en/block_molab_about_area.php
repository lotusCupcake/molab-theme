<?php
$string['pluginname'] = '[Molab] About Area';
$string['molab_about_area'] = '[Molab] About Area';
$string['blocksettings'] = '[Molab] About Area Block Settings';
$string['molab_about_area:addinstance'] = 'Add a new [Molab] About Area block';
$string['molab_about_area:myaddinstance'] = 'Add a new [Molab] About Area block';