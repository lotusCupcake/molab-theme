<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');

class block_molab_banner_2 extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_banner_2');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');

        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->top_title = 'FOR A BETTER FUTURE';
            $this->config->title = 'A Course Is Essential For Building A <span>Career</span>';
            $this->config->body = 'The experience of our instructors benefits your career';
            $this->config->btn = 'Find Courses';
            $this->config->button_link = $CFG->wwwroot . '/course';
            $this->config->bottom_title = '<h6>Total Online Student</h6><h3>125,000 +</h3>';
            $this->config->banner_bg_img = $CFG->wwwroot .'/theme/molab/pix/banner/banner-bg-2.webp';
            $this->config->shape_image = $CFG->wwwroot .'/theme/molab/pix/banner/banner-bg-shape.webp';
            $this->config->banner_img = $CFG->wwwroot .'/theme/molab/pix/banner/banner-img-2.webp';
            $this->config->bottom_content_img = $CFG->wwwroot .'/theme/molab/pix/banner/students.webp';
        }
    }

    public function get_content() {
        global $CFG, $DB;

        if ($this->content !== null) {
          return $this->content;
        }

        $this->content  =  new stdClass;

        $text = '';
        $text .= '
        <div class="banner-area bg-2"  style="background-image:url('.$this->config->banner_bg_img.');">
			<div class="d-table">
				<div class="d-table-cell">
					<div class="container-flud">
						<div class="row align-items-center">
							<div class="col-lg-6">
								<div class="banner-content">
									<span class="top-title">'.$this->config->top_title.'</span>
									<h1>'.$this->config->title.'</h1>
									<p>'.$this->config->body.'</p>';

                                    if($this->config->btn):
                                        $text .= '
                                        <div class="banner-btn">
                                            <a href="'.$this->config->button_link.'" class="default-btn">
                                                '.$this->config->btn.'
                                            </a>
                                        </div>';
                                    endif;
                                    $text .= '
								</div>
							</div>

							<div class="col-lg-6">
								<div class="banner-img banner-img-2" data-speed="0.09" data-revert="true">';
                                    if($this->config->banner_img):
                                        $text .= '
                                        <img src="'.molab_block_image_process($this->config->banner_img).'" alt="'.$this->config->title.'">';
                                    endif;
                                    $text .= '
								</div>
							</div>
						</div>

						<div class="new-additions online-student" data-speed="0.09" data-revert="true">';
                            if($this->config->bottom_content_img):
                                $text .= '
                                <div class="new-brand">
                                    <img src="'.molab_block_image_process($this->config->bottom_content_img).'" alt="'.$this->config->title.'">
                                </div>';
                            endif;
                            $text .= '

                            '.$this->config->bottom_title.'
						</div>
					</div>
				</div>
			</div>';

            if($this->config->shape_image):
                $text .= '
			    <div class="banner-bg-shape" data-speed="0.09" data-revert="true">
                    <img src="'.molab_block_image_process($this->config->shape_image).'" alt="'.$this->config->title.'">
                </div>';
            endif;
            $text .= '
		</div>';
        
        $this->content         =  new stdClass;
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}