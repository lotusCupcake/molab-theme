<?php
$string['pluginname'] = '[Molab] CTA Area ';
$string['molab_cta'] = '[Molab] CTA Area ';
$string['blocksettings'] = '[Molab] CTA Area Block Settings';
$string['molab_cta:addinstance'] = 'Add a new [Molab] CTA Area block';
$string['molab_cta:myaddinstance'] = 'Add a new [Molab] CTA Area block';