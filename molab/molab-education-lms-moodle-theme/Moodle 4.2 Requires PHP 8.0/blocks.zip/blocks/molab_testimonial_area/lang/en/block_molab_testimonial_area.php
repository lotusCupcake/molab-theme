<?php
$string['pluginname'] = '[Molab] Testimonial Area';
$string['molab_testimonial_area'] = '[Molab] Testimonial Area';
$string['blocksettings'] = '[Molab] Testimonial Block Settings';
$string['molab_testimonial_area:addinstance'] = 'Add a new [Molab] Testimonial Area block';
$string['molab_testimonial_area:myaddinstance'] = 'Add a new [Molab] Testimonial Area block';