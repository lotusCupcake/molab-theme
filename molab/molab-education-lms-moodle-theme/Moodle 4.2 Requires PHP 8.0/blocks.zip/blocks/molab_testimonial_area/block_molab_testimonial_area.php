<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_testimonial_area extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_testimonial_area');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->class = 'our-happy-student-area pb-100';
            $this->config->title = 'What Our Happy Student Say';
            $this->config->slider_content1  = '"Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla quis lorem ut libero malesuada feugiat."';
            $this->config->slider_content2  = '"Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla quis lorem ut libero malesuada feugiat."';
            $this->config->btn = 'View All';
            $this->config->link = '#';
            $this->config->shape_img       = $CFG->wwwroot .'/theme/molab/pix/quat.png';
            $this->config->img1            = $CFG->wwwroot .'/theme/molab/pix/happy-student-1.webp';
            $this->config->img2            = $CFG->wwwroot .'/theme/molab/pix/happy-student-2.webp';
            $this->config->slider_name1         = 'James katliv';
            $this->config->slider_designation1  = 'Student';
            $this->config->slider_name2         = 'Alex Dew';
            $this->config->slider_designation2  = 'Student Gardant';
            $this->config->style = 1;
        }
    }

    public function get_content() {
        global $CFG, $DB;

        $this->content         =  new stdClass;

        $sliderNumber = 2;
        if(isset($this->config->sliderNumber)){
            $sliderNumber = $this->config->sliderNumber;
        }
        
        $style = 1;
        if(isset($this->config->style)){
            $style = $this->config->style;
        }

        $text = '';
        if($style == 3):
            $text .= '
            <div class="'.$this->config->class.'">
                <div class="container">
				    <div class="section-title">
                        <h2>'.$this->config->title.'</h2>';
                        if($this->config->btn):
                            $text .= '
                            <a href="'.$this->config->link.'" class="default-btn">
                                '.$this->config->btn.'
                            </a>';
                        endif;
                        $text .= '
                    </div>
                    
                    <div class="our-happy-student-slide owl-carousel owl-theme">';
                        for($i = 1; $i <= $sliderNumber; $i++) {
                            $img                    = 'img' . $i;
                            $slider_content         = 'slider_content' . $i;
                            $slider_name            = 'slider_name' . $i;
                            $slider_designation     = 'slider_designation' . $i;

                            // Image
                            if(isset($this->config->$img)) { $img = $this->config->$img; }else{ $img = ''; }

                            // Content
                            if(isset($this->config->$slider_content)) { $slider_content = $this->config->$slider_content; }else{ $slider_content = ''; }

                            // Name
                            if(isset($this->config->$slider_name)) { $slider_name = $this->config->$slider_name; }else{ $slider_name = ''; }

                            // Designation
                            if(isset($this->config->$slider_designation)) { $slider_designation = $this->config->$slider_designation; }else{ $slider_designation = ''; }
                            $text .= '
                            <div class="row align-items-center">
                                <div class="col-lg-5">
                                    <div class="happy-student-img">';
                                        if($img):
                                            $text .= '
                                            <img src="'.molab_block_image_process($img).'" alt="'.$slider_title.'">';
                                        endif;
                                        $text .= '
                                    </div>
                                </div>
            
                                <div class="col-lg-7">
                                    <div class="happy-student-content ml-15">';
                                        if($this->config->shape_img):
                                            $text .= '
                                            <img src="'.molab_block_image_process($this->config->shape_img).'" alt="'.$slider_title.'">';
                                        endif;
                                        $text .= '
                                        <p>'.$slider_content.'</p>
                                        <h3>'.$slider_name.'</h3>
                                        <span>'.$slider_designation.'</span>
                                    </div>
                                </div>
                            </div>';
                        } $text .= '
                    </div>
                </div>';
                if($this->config->shape_img2):
                    $text .= '                
                    <div class="shape character-swinging" data-speed="0.09" data-revert="true">
                        <img src="'.molab_block_image_process($this->config->shape_img2).'">
                    </div>';
                endif;
                $text .= '
            </div>';
        elseif($style == 2):
            $text .= '
            <div class="'.$this->config->class.'">
                <div class="container">
				    <div class="section-title left-title d-flex justify-content-between align-items-center">
                        <h2>'.$this->config->title.'</h2>';
                        if($this->config->btn):
                            $text .= '
                            <a href="'.$this->config->link.'" class="default-btn">
                                '.$this->config->btn.'
                            </a>';
                        endif;
                        $text .= '
                    </div>
                    
                    <div class="owl-carousel owl-theme our-happy-student-slide-two">';
                        for($i = 1; $i <= $sliderNumber; $i++) {
                            $img                    = 'img' . $i;
                            $slider_content         = 'slider_content' . $i;
                            $slider_name            = 'slider_name' . $i;
                            $slider_designation     = 'slider_designation' . $i;
                            $slider_rating          = 'slider_rating' . $i;

                            // Image
                            if(isset($this->config->$img)) { $img = $this->config->$img; }else{ $img = ''; }

                            // Content
                            if(isset($this->config->$slider_content)) { $slider_content = $this->config->$slider_content; }else{ $slider_content = ''; }

                            // Name
                            if(isset($this->config->$slider_name)) { $slider_name = $this->config->$slider_name; }else{ $slider_name = ''; }

                            if(isset($this->config->$slider_rating)) { $slider_rating = $this->config->$slider_rating; }else{ $slider_rating = ''; }

                            // Designation
                            if(isset($this->config->$slider_designation)) { $slider_designation = $this->config->$slider_designation; }else{ $slider_designation = ''; }
                            $text .= '
                            <div class="our-happy-student-style-two-item">
                                <div class="d-flex justify-content-between align-items-end">
                                    <div class="happy-student-avatar">';
                                        if($img):
                                            $text .= '
                                            <img src="'.molab_block_image_process($img).'" alt="'.$slider_title.'">';
                                        endif;
                                        $text .= '
                                        <div class="d-inline-block">
                                            <h3>'.$slider_name.'</h3>
                                            <span>'.$slider_designation.'</span>
                                        </div>
                                    </div>

                                    <ul>';
                                        for ($c = 1; $c <= $slider_rating; $c++) {
                                            $text .= '
                                            <li>
                                                <i class="ri-star-fill"></i>
                                            </li> ';
                                        } $text .= '
                                    </ul>
                                </div>
                                <p>'.$slider_content.'</p>';

                                if($this->config->shape_img):
                                    $text .= '
                                    <img src="'.molab_block_image_process($this->config->shape_img).'" class="quat-s" alt="'.$slider_title.'">';
                                endif;
                                $text .= '
                            </div>';
                        } $text .= '
                    </div>
                </div>
            </div>';
        else:
            $text .= '
            <div class="'.$this->config->class.'">
                <div class="container">
                    <div class="section-title left-title d-flex justify-content-between align-items-center">
                        <h2>'.$this->config->title.'</h2>';
                        if($this->config->btn):
                            $text .= '
                            <a href="'.$this->config->link.'" class="default-btn">
                                '.$this->config->btn.'
                            </a>';
                        endif;
                        $text .= '
                    </div>
                    
                    <div class="our-happy-student-slide owl-carousel owl-theme">';
                        for($i = 1; $i <= $sliderNumber; $i++) {
                            $img                    = 'img' . $i;
                            $slider_content         = 'slider_content' . $i;
                            $slider_name            = 'slider_name' . $i;
                            $slider_designation     = 'slider_designation' . $i;

                            // Image
                            if(isset($this->config->$img)) { $img = $this->config->$img; }else{ $img = ''; }

                            // Content
                            if(isset($this->config->$slider_content)) { $slider_content = $this->config->$slider_content; }else{ $slider_content = ''; }

                            // Name
                            if(isset($this->config->$slider_name)) { $slider_name = $this->config->$slider_name; }else{ $slider_name = ''; }

                            // Designation
                            if(isset($this->config->$slider_designation)) { $slider_designation = $this->config->$slider_designation; }else{ $slider_designation = ''; }
                            $text .= '
                            <div class="row align-items-center">
                                <div class="col-lg-5">
                                    <div class="happy-student-img">';
                                        if($img):
                                            $text .= '
                                            <img src="'.molab_block_image_process($img).'" alt="'.$slider_title.'">';
                                        endif;
                                        $text .= '
                                    </div>
                                </div>
            
                                <div class="col-lg-7">
                                    <div class="happy-student-content ml-15">';
                                        if($this->config->shape_img):
                                            $text .= '
                                            <img src="'.molab_block_image_process($this->config->shape_img).'" alt="'.$slider_title.'">';
                                        endif;
                                        $text .= '
                                        <p>'.$slider_content.'</p>
                                        <h3>'.$slider_name.'</h3>
                                        <span>'.$slider_designation.'</span>
                                    </div>
                                </div>
                            </div>';
                        } $text .= '
                    </div>
                </div>
            </div>';
        endif;
        
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}