<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_partners extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_partners');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();    
            $this->config->class = 'partner-area ptb-100';
            $this->config->body = 'Join Businesses Around The World Who Believe In <span>Molab</span>';
        }
    }

    public function get_content() {
        global $CFG, $DB;
        require_once($CFG->libdir . '/filelib.php');

        if ($this->content !== null) {
          return $this->content;
        }

        $this->content         =  new stdClass;

        if(!empty($this->config->class)){
            $this->content->class = $this->config->class;
        }else{
            $this->content->class = '';
        }

        if(!empty($this->config->body)){
            $this->content->body = $this->config->body;
        }else{
            $this->content->body = '';
        }
        
        $text = '';
        $text .= '
        <div class="'.$this->content->class.'">
			<div class="container">
				<div class="section-title">
					<h2>'.$this->content->body.'</h2>
				</div>

				<div class="partner-slider owl-carousel owl-theme">';
                    $fs = get_file_storage();
                    $files = $fs->get_area_files($this->context->id, 'block_molab_partners', 'content');
                    foreach ($files as $file) {
                        $filename = $file->get_filename();
                        if ($filename <> '.') {
                            $url = moodle_url::make_pluginfile_url($file->get_contextid(), $file->get_component(), $file->get_filearea(), null, $file->get_filepath(), $filename);
                            $text .= '
                            <div class="partner-item">
                                <img src="'. $url.'" alt="'. $filename.'">
                            </div>';
                        }
                    } $text .= '
				</div>
			</div>
		</div>';

        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}