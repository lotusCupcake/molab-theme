<?php

class block_molab_funfacts_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;
        $molabFontList = include($CFG->dirroot . '/theme/molab/inc/font_handler/molab_font_select.php');

        $funfactsnumber = 4;
        if(isset($this->block->config->funfactsnumber)){
            $funfactsnumber = $this->block->config->funfactsnumber;
        }

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        // Class
        $mform->addElement('text', 'config_class', get_string('config_class', 'theme_molab'));
        $mform->setDefault('config_class', 'counter-area pt-70 pb-100');
        $mform->setType('config_class', PARAM_RAW);

        // Title
        $mform->addElement('text', 'config_title', get_string('config_title', 'theme_molab'));
        $mform->setDefault('config_title', 'Our Achievements');
        $mform->setType('config_title', PARAM_RAW);

        // Content
        $mform->addElement('textarea', 'config_body', get_string('config_body', 'theme_molab'), 'wrap="virtual" rows="6" cols="50"');
        $mform->setDefault('config_body', 'Learn the secrets of life success, all the successes we have achieved in achieving goals.');

        $funfactsrange = array(
            1 => '1',
            2 => '2',
            3 => '3',
            4 => '4',
            5 => '5',
            6 => '6',
            7 => '7',
            8 => '8',
            9 => '9',
            10 => '10',
            11 => '11',
            12 => '12',
            13 => '13',
            14 => '14',
            15 => '15',
            16 => '16',
            17 => '17',
            18 => '18',
            19 => '19',
            20 => '20',
            21 => '21',
            22 => '22',
            23 => '23',
            24 => '24',
            25 => '25',
            26 => '26',
            27 => '27',
            28 => '28',
            29 => '29',
            30 => '30',
        );

        $mform->addElement('select', 'config_funfactsnumber', get_string('config_items', 'theme_molab'), $funfactsrange);
        $mform->setDefault('config_funfactsnumber', 4);

        for($i = 1; $i <= $funfactsnumber; $i++) {
            $mform->addElement('header', 'config_molab_item' . $i , get_string('config_item', 'theme_molab') . $i);

            $mform->addElement('text', 'config_funfacts_title' . $i, get_string('config_title', 'theme_molab', $i));
            $mform->setDefault('config_funfacts_title' . $i, 'Courses & Videos');
            $mform->setType('config_funfacts_title' . $i, PARAM_TEXT);

            $mform->addElement('text', 'config_funfacts_number' . $i, get_string('config_number', 'theme_molab', $i));
            $mform->setDefault('config_funfacts_number' . $i, '125000');
            $mform->setType('config_funfacts_number' . $i, PARAM_TEXT);

            $mform->addElement('text', 'config_funfacts_prefix' . $i, get_string('config_number_prefix', 'theme_molab', $i));
            $mform->setDefault('config_funfacts_prefix' . $i, '+');
            $mform->setType('config_funfacts_prefix' . $i, PARAM_TEXT);

        }

        // Image URL
        $mform->addElement('static', 'config_image_doc', '<b><a style="color: var(--main-color)" href="https://docs.envytheme.com/docs/molab-moodle-theme-documentation/faqs/how-to-get-the-image-url/" target="_blank">Doc link: How to make Image URL?</a></b>'); 

        $mform->addElement('text', 'config_img', 'Section Image 1 URL(Image recommended size 114X178)');
        $mform->setDefault('config_img', $CFG->wwwroot .'/theme/molab/pix/achievements-img.webp');
        $mform->setType('config_img', PARAM_TEXT);

        $mform->addElement('text', 'config_shape_img', 'Shape Image URL');
        $mform->setDefault('config_shape_img', $CFG->wwwroot .'/theme/molab/pix/counter-shape.webp');
        $mform->setType('config_shape_img', PARAM_TEXT);
    }
}
