<?php
$string['pluginname'] = '[Molab] FAQs';
$string['molab_faq'] = '[Molab] FAQs';
$string['blocksettings'] = '[Molab] FAQs Block Settings';
$string['molab_faq:addinstance'] = 'Add a new [Molab] FAQs block';
$string['molab_faq:myaddinstance'] = 'Add a new [Molab] FAQs block';