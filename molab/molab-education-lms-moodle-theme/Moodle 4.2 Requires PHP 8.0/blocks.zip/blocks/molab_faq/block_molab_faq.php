<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_faq extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_faq');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->faqnumber = 5;
            $this->config->title = 'Frequently Asked Questions            ';
            $this->config->item_title1 = 'How Do We Create Course Content?';
            $this->config->item_content1 = 'Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula sed magna dictum porta. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel aliquet quam id dui posuere blandit Contact Us.';
            $this->config->item_title2 = 'How Do I Reset My Account Password?';
            $this->config->item_content2 = 'Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula sed magna dictum porta. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel aliquet quam id dui posuere blandit Contact Us.';
            $this->config->item_title3 = 'How Can I Manage My Account?';
            $this->config->item_content3 = 'Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula sed magna dictum porta. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel aliquet quam id dui posuere blandit Contact Us.';
            $this->config->item_title4 = 'What Are The Benefits Of Lemy Learning?';
            $this->config->item_content4 = 'Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula sed magna dictum porta. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel aliquet quam id dui posuere blandit Contact Us.';
            $this->config->item_title5 = 'Is Support For Learners Included?';
            $this->config->item_content5 = 'Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula sed magna dictum porta. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel aliquet quam id dui posuere blandit Contact Us.';
            $this->config->img = $CFG->wwwroot .'/theme/molab/pix/faq-img.webp';
        }
    }

    public function get_content() {
        global $CFG, $DB;

        if ($this->content !== null) {
            return $this->content;
        }
  
        $this->content         =  new stdClass;

        $faqnumber = 5;
        if(isset($this->config->faqnumber)){
            $faqnumber = $this->config->faqnumber;
        } 
        $text = '';
        $text .= '
        <div class="faq-area bg-color-fdfcfc pt-100 pb-70">
			<div class="container">
				<div class="section-title">
					<h2>'.$this->config->title.'</h2>
				</div>

				<div class="row align-items-center">
					<div class="col-lg-6">
						<div class="accordion" id="accordionExample">';
                            for($i = 1; $i <= $faqnumber; $i++) {
                                $item_title     = 'item_title' . $i;
                                $item_content   = 'item_content' . $i;

                                if(isset($this->config->$item_title)) {
                                    $item_title = $this->config->$item_title;
                                }else{
                                    $item_title = '';
                                }
                                if(isset($this->config->$item_content)) {
                                    $item_content = $this->config->$item_content;
                                }else{
                                    $item_content = '';
                                }
                                if($i == 1):
                                    $text .= '
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="heading'.$i.'">
                                            <button class="accordion-button" type="button" data-toggle="collapse" data-target="#collapse'.$i.'" aria-expanded="true" aria-controls="collapse'.$i.'">
                                                '.$item_title.'
                                            </button>
                                        </h2>
                                        <div id="collapse'.$i.'" class="accordion-collapse collapse show" aria-labelledby="heading'.$i.'" data-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <p>'.$item_content.'</p>
                                            </div>
                                        </div>
                                    </div>';
                                else:
                                    $text .= '
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="heading'.$i.'">
                                            <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapse'.$i.'" aria-expanded="false" aria-controls="collapse'.$i.'">
                                                '.$item_title.'
                                            </button>
                                        </h2>
                                        <div id="collapse'.$i.'" class="accordion-collapse collapse" aria-labelledby="heading'.$i.'" data-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <p>'.$item_content.'</p>
                                            </div>
                                        </div>
                                    </div>';
                                endif;
                            }
                            $text .= '
						</div>
					</div>

					<div class="col-lg-6">
						<div class="faq-img">';
                            if($this->config->img):
                                $text .= '<img src="'.molab_block_image_process($this->config->img).'" alt="'.$this->config->title.'">';
                            endif; 
                            $text .= '
						</div>
					</div>
				</div>
			</div>
		</div>';
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}