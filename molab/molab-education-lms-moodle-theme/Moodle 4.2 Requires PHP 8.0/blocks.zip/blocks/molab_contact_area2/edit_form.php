<?php

class block_molab_contact_area2_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        // Title
        $mform->addElement('text', 'config_title', 'Form Title');
        $mform->setDefault('config_title', 'Learn At Your Own Pace, With Lifetime Access Anywhere And Any Device');
        $mform->setType('config_title', PARAM_RAW);

        $mform->addElement('textarea', 'config_contact_from_code', 'Form Code', 'wrap="virtual" rows="10" cols="70"');

        $mform->addElement('static', 'config_cotact_doc', '<b><a style="color: var(--main-color)" href="https://moodle.org/plugins/local_contact" target="_blank">Please make sure Contact Form plugin is installed.</a></b>'); 

        // Section Image
        $mform->addElement('text', 'config_section_img', 'Section Image URL');
        $mform->setDefault('config_section_img', $CFG->wwwroot .'/theme/molab/pix/life-time.webp');
        $mform->setType('config_section_img', PARAM_TEXT);

        // Shape Image
        $mform->addElement('text', 'config_shape_img', 'Shape Image URL');
        $mform->setDefault('config_shape_img', $CFG->wwwroot .'/theme/molab/pix/about-shape-1.webp');
        $mform->setType('config_shape_img', PARAM_TEXT);
    }
}
