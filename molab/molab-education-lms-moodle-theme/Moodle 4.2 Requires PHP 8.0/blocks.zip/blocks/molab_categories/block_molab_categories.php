<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/course_handler/molab_course_handler.php');
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_categories extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_categories');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $molabCourseHandler = new molabCourseHandler();
            $molabCategories = $molabCourseHandler->molabGetExampleCategoriesIds(8);
            $this->config = new \stdClass();
            $this->config->class            = 'categories-area pt-100 pb-70';
            $this->config->title            = 'Explore The Categories';
            $this->config->img1 = $CFG->wwwroot.'/theme/molab/pix/categories/categories-1.webp';
            $this->config->img2 = $CFG->wwwroot.'/theme/molab/pix/categories/categories-2.webp';
            $this->config->img3 = $CFG->wwwroot.'/theme/molab/pix/categories/categories-3.webp';
            $this->config->img4 = $CFG->wwwroot.'/theme/molab/pix/categories/categories-4.webp';
            $this->config->img5 = $CFG->wwwroot.'/theme/molab/pix/categories/categories-5.webp';
        }
    }

    public function get_content() {
        global $CFG, $USER, $DB, $OUTPUT;

        if ($this->content !== null) {
            return $this->content;
        }

        if (isset($this->config->items)) {
            $data = $this->config;
            $data->items = is_numeric($data->items) ? (int)$data->items : 5;
        } else {
            $data = new stdClass();
            $data->items = '0';
        }

        $this->content         =  new stdClass;


        if(!empty($this->config->title)){$this->content->title = $this->config->title;} else {$this->content->title = '';}

        $text = '';
        $text .= '
        <div class="'.$this->config->class.'">
			<div class="container">
				<div class="section-title left-title">
					<h2>'.$this->content->title.'</h2>
				</div>

				<div class="categories-slide owl-carousel owl-theme">';
                    $topcategory = core_course_category::top();
                    
                    if ($data->items > 0) {
                        for ($i = 1; $i <= $data->items; $i++) {
                            $img            = 'img' . $i;
                            $categoryID     = 'category' . $i;
                            $category       = $DB->get_record('course_categories',array('id' => $data->$categoryID));

                            // Image
                            if(isset($this->config->$img)) { $img = $this->config->$img; }else{ $img = ''; }

                            if ($DB->record_exists('course_categories', array('id' => $data->$categoryID))) {
                                $chelper = new coursecat_helper();
                                $categoryID = $category->id;
                                $category = core_course_category::get($categoryID);
                                $categoryname = $category->get_formatted_name();
                                $children_courses = $category->get_courses();
                                if($children_courses >= 1){
                                    $countNoOfCourses = '<p>'.count($children_courses).'</p>';
                                } else {
                                    $countNoOfCourses = '';
                                }
                                $text .= '
                                <div class="single-categories-item">';
                                    if($img):
                                        $text .= '
                                        <a href="'.$CFG->wwwroot .'/course/index.php?categoryid='.$categoryID.'" class="categories-img">
                                            <img src="'.molab_block_image_process($img).'" alt="'.$categoryname.'">
                                        </a>';
                                    endif;
                                    $text .= '
                                    <a href="'.$CFG->wwwroot .'/course/index.php?categoryid='.$categoryID.'">
                                        <h3>'.$categoryname.'</h3>
                                    </a>
                                </div>';
                            }
                        }
                    }
                    $text .= '
				</div>
			</div>
		</div>';

        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    function instance_allow_config() {
        return true;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}