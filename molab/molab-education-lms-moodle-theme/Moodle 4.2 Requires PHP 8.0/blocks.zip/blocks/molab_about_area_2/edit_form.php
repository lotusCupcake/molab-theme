<?php

class block_molab_about_area_2_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;
        $molabFontList = include($CFG->dirroot . '/theme/molab/inc/font_handler/molab_font_select.php');

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        // Title
        $mform->addElement('text', 'config_title', 'Banner Title');
        $mform->setDefault('config_title', 'We Share Knowledge Among The World');
        $mform->setType('config_title', PARAM_RAW);

        // Content
        $mform->addElement('textarea', 'config_body', get_string('config_body', 'theme_molab'), 'wrap="virtual" rows="6" cols="50"');
        $mform->setDefault('config_body', '<p>Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>
        <p>Proin eget tortor risus. Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Mauris blandit aliquet elit, egettincidunt nibh pulvinar ultricies ligula sed magna dictum porta.</p>');

        // Button Text
        $mform->addElement('text', 'config_btn', 'Button Text');
        $mform->setDefault('config_btn', 'Read More');
        $mform->setType('config_btn', PARAM_RAW);

        // Button Link
        $mform->addElement('text', 'config_button_link', 'Button Link');
        $mform->setDefault('config_button_link', $CFG->wwwroot . '/course');
        $mform->setType('config_button_link', PARAM_RAW);

        // Section Image header title according to language file.
        $mform->addElement('header', 'config_image_heading', get_string('config_image_heading', 'theme_molab'));

        $mform->addElement('static', 'config_image_doc', '<b><a style="color: var(--main-color)" href="https://docs.envytheme.com/docs/molab-moodle-theme-documentation/faqs/how-to-get-the-image-url/" target="_blank">Doc link: How to make Image URL?</a></b>'); 

        // Section Image
        $mform->addElement('text', 'config_section_img', 'Section Image URL');
        $mform->setDefault('config_section_img', $CFG->wwwroot .'/theme/molab/pix/about-img.webp');
        $mform->setType('config_section_img', PARAM_TEXT);

        // Shape Image
        $mform->addElement('text', 'config_shape_image', 'Section Shape Image URL');
        $mform->setDefault('config_shape_image', $CFG->wwwroot .'/theme/molab/pix/about-shape-1.webp');
        $mform->setType('config_shape_image', PARAM_TEXT);

        // Shape Image
        $mform->addElement('text', 'config_shape_image2', 'Section Shape Image Two URL');
        $mform->setDefault('config_shape_image2', $CFG->wwwroot .'/theme/molab/pix/about-shape-2.webp');
        $mform->setType('config_shape_image2', PARAM_TEXT);
    }
}
