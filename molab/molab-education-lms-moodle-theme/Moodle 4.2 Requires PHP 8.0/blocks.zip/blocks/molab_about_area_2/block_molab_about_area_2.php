<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');

class block_molab_about_area_2 extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_about_area_2');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');

        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->title = 'We Share Knowledge Among The World';
            $this->config->body = '<p>Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>
<p>Proin eget tortor risus. Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Mauris blandit aliquet elit, egettincidunt nibh pulvinar ultricies ligula sed magna dictum porta.</p>';
            $this->config->btn = 'Read More';
            $this->config->button_link = $CFG->wwwroot . '/course';
            $this->config->section_img = $CFG->wwwroot .'/theme/molab/pix/about-img.webp';
            $this->config->shape_image = $CFG->wwwroot .'/theme/molab/pix/about-shape-1.webp';
            $this->config->shape_image2 = $CFG->wwwroot .'/theme/molab/pix/about-shape-2.webp';
        }
    }

    public function get_content() {
        global $CFG, $DB;

        if ($this->content !== null) {
          return $this->content;
        }

        $this->content  =  new stdClass;

        $text = '';
        $text .= '
        <div class="about-area bg-color-f2f8fa pt-100">
			<div class="container">
				<div class="row">
					<div class="col-lg-8 pe-0">
						<div class="about-bg"style="background-image:url('.$this->config->section_img.');"></div>
					</div>
					<div class="col-lg-4 ps-0">
						<div class="about-content">
							<h2>'.$this->config->title.'</h2>
							'.$this->config->body.'';
                            if($this->config->btn):
                                $text .= '
                                <a href="'.$this->config->button_link.'" class="default-btn">
                                    '.$this->config->btn.'
                                </a>';
                            endif;
                            $text .= '
						</div>
					</div>
				</div>
			</div>

			<div class="shape about-shape-1" data-speed="0.09" data-revert="true">';
                if($this->config->shape_image):
                    $text .= '
                    <img src="'.molab_block_image_process($this->config->shape_image).'" alt="'.$this->config->title.'">';
                endif;
                $text .= '
			</div>

			<div class="shape about-shape-2" data-speed="0.09" data-revert="true">';
                if($this->config->shape_image2):
                    $text .= '
                    <img src="'.molab_block_image_process($this->config->shape_image2).'" alt="'.$this->config->title.'">';
                endif;
                $text .= '
			</div>
		</div>';
        
        $this->content         =  new stdClass;
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}