<?php
$string['pluginname'] = '[Molab] Newsletter';
$string['molab_newsletter'] = '[Molab] Newsletter';
$string['blocksettings'] = '[Molab] Newsletter Block Settings';
$string['molab_newsletter:addinstance'] = 'Add a new [Molab] Newsletter block';
$string['molab_newsletter:myaddinstance'] = 'Add a new [Molab] Newsletter block';
$string['config_btn'] = 'Button Text';
$string['config_placeholder'] = 'Placeholder Text';
$string['config_action_url'] = 'MailChimp Action URL';