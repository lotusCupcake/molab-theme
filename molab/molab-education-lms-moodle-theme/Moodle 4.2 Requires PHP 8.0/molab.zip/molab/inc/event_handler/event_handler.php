<?php

defined('MOODLE_INTERNAL') || die();

// require_once($CFG->dirroot. '/course/renderer.php');

class molabEventHandler {
    public function molabEventList() {

        global $DB;

        $molabEvents = $DB->get_records('event', array(), $sort='', $fields='*', $limitfrom=1, $limitnum=$maxNum);

        $molabReturn = [];

        foreach($molabEvents as $k=>$molabEvent){
        $molabReturn[$molabEvent->id] = $molabEvent;
        }

        // print_object($molabReturn);

        return $molabReturn;

    }

    public function molabGetEvent($eventId){
        global $DB;

        if ($DB->record_exists('event', array('id' => $eventId))) {

        $event = $DB->get_record('event', array('id' => $eventId));

        $molabReturn = new \stdClass();
        $molabReturn->id = $event->id;
        $molabReturn->name = $event->name;
        $molabReturn->timestart = userdate($event->timestart, get_string('strftimedaydatetime', 'langconfig'));
        $molabReturn->dateYear = userdate($event->timestart, '%Y', 0);
        $molabReturn->dateMonth = userdate($event->timestart, '%b', 0);
        $molabReturn->dateDay = userdate($event->timestart, '%d', 0);
        $molabReturn->location = $event->location;
        $molabReturn->description = $event->description;
        $molabReturn->eventtype = $event->eventtype;
        $molabReturn->timeduration = $event->timeduration;

        return $molabReturn;

        }

        return NULL;

    }

    public function molabGetExampleEventIds($maxNum) {
        global $CFG, $DB;

        $molabEvents = $DB->get_records('event', array(), $sort='', $fields='*', $limitfrom=1, $limitnum=$maxNum);

        $molabReturn = array();
        foreach ($molabEvents as $k=>$molabEvent) {
        $molabReturn[] = $molabEvent->id;
        }
        return $molabReturn;
    }

}