<?php
/*
@molabRef: @block_molab/block.php
*/

defined('MOODLE_INTERNAL') || die();

// print_object($this);
$molabBlockType = $this->instance->blockname;

$molabCollectionFullwidthTop =  array(
    "molab_banner_1",
    "molab_features_area",
    "molab_categories",
    "molab_course_filter",
    "molab_funfacts",
    "molab_event_area",
    "molab_instructor_area",
    "molab_cta",
    "molab_blog_area",
    "molab_about_area",
    "molab_faq",
    "molab_contact_area",
    "molab_banner_2",
    "molab_about_area_2",
    "molab_funfacts_2",
    "molab_partners",
    "molab_contact_area2",
    
    "molab_features_area_two",
    "molab_about_area_two",
    "molab_newsletter",
    "molab_about_area_three",
    "molab_video_area",
    "molab_single_feedback",
    "molab_success_overview_area",
    "molab_gallery",
    "molab_contact_info",
    "molab_contact",
    "molab_faq",
    "molab_testimonial_area",
    
    "molab_authors_area",
    "molab_testimonial_area_two",
    "molab_contact_features",
    "molab_funfacts_two",
    "molab_banner_3",
    "molab_about_area_four",
    "molab_career_area",
);

$molabCollectionAboveContent =  array(
    "molab_contact_form",
    "molab_course_desc",
);

$molabCollectionBelowContent =  array(
    "molab_course_rating",
    "molab_more_courses",
    "molab_course_instructor",
);

$molabCollection = array_merge($molabCollectionFullwidthTop, $molabCollectionAboveContent, $molabCollectionBelowContent);

if (empty($this->config)) {
    if(in_array($molabBlockType, $molabCollectionFullwidthTop)) {
        $this->instance->defaultregion = 'fullwidth-top';
        $this->instance->region = 'fullwidth-top';
        $DB->update_record('block_instances', $this->instance);
    }
    if(in_array($molabBlockType, $molabCollectionAboveContent)) {
        $this->instance->defaultregion = 'above-content';
        $this->instance->region = 'above-content';
        $DB->update_record('block_instances', $this->instance);
    }
    if(in_array($molabBlockType, $molabCollectionBelowContent)) {
        $this->instance->defaultregion = 'below-content';
        $this->instance->region = 'below-content';
        $DB->update_record('block_instances', $this->instance);
    }
}
