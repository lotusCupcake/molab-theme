(function($) {
    $(document).ready(function() {
    // Custom Select Search w/ Icons
        $("div[id$='molab_icon_class'], div[id^='molab_icon_class'], .molab_icon_class").each(function() {
            $(this).find(".custom-select").each(function() {
                $(this).wrap("<div class='ui_kit_select_search'></div>");
                $(this).find("option").each(function() {
                    var $molabIcon = $(this).attr("value");
                    $(this).attr("data-tokens", $molabIcon).attr("data-icon", $molabIcon).attr("data-subtext", $molabIcon);
                });
                $(this).addClass("selectpicker").attr("data-live-search", "true").attr("data-width", "100%").removeClass("custom-select");
            });
        });
    });

  }(jQuery));
