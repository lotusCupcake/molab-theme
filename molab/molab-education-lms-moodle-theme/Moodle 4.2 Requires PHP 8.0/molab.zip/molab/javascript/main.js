(function($){
    (function($) {
        "use strict";

		$(document).ready(function() {
			// Support Moodle MultiLang
			var langValue = $("html").attr("lang");
			$('.multilang').each(function(){
				var currentLangValue = $(this).attr("lang");
				if(langValue != currentLangValue) {
					$(this).addClass('d-none');
				}
			});
			
            var current_site_url = $(".navbar-area .navbar .navbar-brand").attr("href");
            if (current_site_url) {
				if (current_site_url != 'http://localhost/moodle/molab/') {
					$('a').each(function () {
						var url = $(this).attr("href");
						if (url.includes("http://localhost/moodle/molab/")) {
							url = url.replace("http://localhost/moodle/molab/", current_site_url);
							$(this).attr('href', url);
						}
					});

					$('img').each(function () {
						var url = $(this).attr("src");
						if (url.includes("http://localhost/moodle/molab/")) {
							url = url.replace("http://localhost/moodle/molab/", current_site_url);
							$(this).attr('src', url);
						}
					});
				}
                if (current_site_url != 'http://localhost:8888/moodle/molab/') {
					$('a').each(function () {
						var url = $(this).attr("href");
						if (url.includes("http://localhost:8888/moodle/molab/")) {
							url = url.replace("http://localhost:8888/moodle/molab/", current_site_url);
							$(this).attr('href', url);
						}
					});

					$('img').each(function () {
						var url = $(this).attr("src");
						if (url.includes("http://localhost:8888/moodle/molab/")) {
							url = url.replace("http://localhost:8888/moodle/molab/", current_site_url);
							$(this).attr('src', url);
						}
					});
				}
			}
            
            $("body.role-standard:not(.path-contentbank):not(#page-contentbank) .bottom-region-main-box").each(function() {
                if (!$(this).find(".block").length && !$(this).find(".molab-main").text().trim().length) {
                $(".bottom-region-main-box, .bottom-region-main-box #page-content").css({
                    'padding-top': '0',
                    'margin-top': '0',
                    'padding-bottom': '0px !important',
                });
                $(".molab-main").remove();
                }
            });

            $(".dashbord_nav_list > a:first-child").prepend("<i class='bx bxs-dashboard' ></i>");
            $(".dashbord_nav_list > a:nth-child(2)").prepend("<i class='bx bx-user' ></i>");
            $(".dashbord_nav_list > a:nth-child(3)").prepend("<i class='bx bxs-graduation' ></i>");
            $(".dashbord_nav_list > a:nth-child(4)").prepend("<i class='bx bx-chat' ></i>");
            $(".dashbord_nav_list > a:nth-child(5)").prepend("<i class='bx bx-cog' ></i>");
            $(".dashbord_nav_list > a:nth-child(6)").prepend("<i class='bx bx-log-out' ></i>");
            $(".dashbord_nav_list > a:nth-child(7)").prepend("<i class='bx bx-user-plus' ></i>");
            $(".dashbord_nav_list > a:nth-child(8)").prepend("<i class='bx bx-log-out'></i>");
            $(".dashbord_nav_list > a").each(function() {
            $(this).removeClass("dropdown-item").wrap("<li></li>");
            });
            $(".dashbord_nav_list > li").wrapAll("<ul></ul>");

			// Mean Menu
			$('.mean-menu').meanmenu({
				meanScreenWidth: "991"
			});

			// Search Popup JS
			$('.close-btn').on('click', function() {
				$('.search-overlay').fadeOut();
				$('.search-btn').show();
				$('.close-btn').removeClass('active');
			});
			$('.search-btn').on('click', function() {
				if ($(".meanmenu-reveal.meanclose")[0]){
					$('.meanmenu-reveal').click();
				}
				$(this).hide();
				$('.search-overlay').fadeIn();
				$('.close-btn').addClass('active');
			});

			$(".mobile-responsive-nav .meanmenu-reveal").on("click", function(){
				$('.search-overlay').fadeOut();
				$('.search-btn').show();
				$('.close-btn').removeClass('active');
			});

			// Popup Video
			$('.popup-video').magnificPopup({
				disableOn: 320,
				type: 'iframe',
				mainClass: 'mfp-fade',
				removalDelay: 160,
				preloader: false,
				fixedContentPos: false
			});

			$('.gallery-item').magnificPopup({
				type: 'image',
				gallery:{
				enabled:true
				}
			});

			// Click Event JS
			$('.go-top').on('click', function() {
				$("html, body").animate({ scrollTop: "0" }, 100);
			});
			
			$(".popover-region-notifications").click(function() {
				$(".popover-region-notifications").toggleClass('collapsed');
			});

        });

		// Search Popup JS
		$('.close-btn').on('click', function() {
			$('.search-overlay').fadeOut();
			$('.search-btn').show();
			$('.close-btn').removeClass('active');
		});
		$('.search-btn').on('click', function() {
			if ($(".meanmenu-reveal.meanclose")[0]){
				$('.meanmenu-reveal').click();
			}
			$(this).hide();
			$('.search-overlay').fadeIn();
			$('.close-btn').addClass('active');
		});

		$(".mobile-responsive-nav .meanmenu-reveal").on("click", function(){
			$('.search-overlay').fadeOut();
			$('.search-btn').show();
			$('.close-btn').removeClass('active');
		});

		// Categories Slide JS
		$('.categories-slide').owlCarousel({
			items: 1,
			loop: false,
			margin: 30,
			nav: true,
			dots: false,
			autoplay: true,
			smartSpeed: 1000,
			autoplayHoverPause: true,
			navText: [
				"<i class='ri-arrow-left-s-line'></i>",
				"<i class='ri-arrow-right-s-line'></i>",
			],
			responsive: {
				0: {
					items: 1,
				},
				414: {
					items: 1,
				},
				576: {
					items: 2,
				},
				768: {
					items: 3,
				},
				992: {
					items: 4,
				},
				1200: {
					items: 5,
				},
			},
		});

		// Instructors Slide JS
		$('.instructors-slide').owlCarousel({
			items: 1,
			loop: true,
			margin: 30,
			nav: true,
			dots: false,
			autoplay: true,
			smartSpeed: 1000,
			autoplayHoverPause: true,
			navText: [
				"<i class='ri-arrow-left-s-line'></i>",
				"<i class='ri-arrow-right-s-line'></i>",
			],
			responsive: {
				0: {
					items: 1,
				},
				414: {
					items: 1,
				},
				576: {
					items: 2,
				},
				768: {
					items: 3,
				},
				992: {
					items: 2,
				},
				1200: {
					items: 3,
				},
			},
		});

		// Partner Slider JS
		$('.partner-slider').owlCarousel({
			loop: true,
			margin: 30,
			nav: false,
			dots: false,
			autoplay: true,
			smartSpeed: 1000,
			autoplayHoverPause: true,
			responsive: {
				0: {
					items: 2,
				},
				414: {
					items: 3,
				},
				576: {
					items: 4,
				},
				768: {
					items: 5,
				},
				992: {
					items: 6,
				},
				1200: {
					items: 6,
				},
			},
		});

		// Our Happy Student Slide JS
		$('.our-happy-student-slide').owlCarousel({
			items: 1,
			loop: true,
			margin: 30,
			nav: true,
			dots: false,
			autoplay: true,
			smartSpeed: 1000,
			autoplayHoverPause: true,
			animateOut: 'fadeOut',
			navText: [
				"<i class='ri-arrow-left-s-line'></i>",
				"<i class='ri-arrow-right-s-line'></i>",
			],
		});

		// Our Happy Student Slide JS
		$('.our-happy-student-slide-two').owlCarousel({
			items: 1,
			loop: true,
			margin: 30,
			nav: false,
			dots: false,
			autoplay: true,
			smartSpeed: 1000,
			autoplayHoverPause: true,
			navText: [
				"<i class='ri-arrow-left-s-line'></i>",
				"<i class='ri-arrow-right-s-line'></i>",
			],
			responsive: {
				0: {
					items: 1,
				},
				414: {
					items: 1,
				},
				576: {
					items: 1,
				},
				768: {
					items: 2,
				},
				992: {
					items: 2,
				},
				1200: {
					items: 2,
				},
			},
		});

		// Related Courses Slider JS
		$('.related-courses-slider').owlCarousel({
			items: 1,
			loop: true,
			margin: 30,
			nav: false,
			dots: true,
			autoplay: true,
			smartSpeed: 1000,
			autoplayHoverPause: true,
		});

		// Preloader
		$(window).on('load', function() {
			$('.preloader').addClass('preloader-deactivate');
		});

		// WOW JS
		if($('.wow').length){
			var wow = new WOW({
				mobile: false
			});
			wow.init();
		}
		
		// Odometer JS
		$('.odometer').appear(function(e) {
			var odo = $(".odometer");
			odo.each(function() {
				var countNumber = $(this).attr("data-count");
				$(this).html(countNumber);
			});
		});
		
		// Popup Video JS
		$('.popup-youtube, .popup-vimeo').magnificPopup({
			disableOn: 300,
			type: 'iframe',
			mainClass: 'mfp-fade',
			removalDelay: 160,
			preloader: false,
			fixedContentPos: false,
		});

		// MixItUp Shorting JS
		$('.shorting').mixItUp();

		// Tabs 
		$('.tab ul.tabs').addClass('active').find('> li:eq(0)').addClass('current');
		$('.tab ul.tabs li').on('click', function (g) {
			var tab = $(this).closest('.tab'), 
			index = $(this).closest('li').index();
			tab.find('ul.tabs > li').removeClass('current');
			$(this).closest('li').addClass('current');
			tab.find('.tab_content').find('div.tabs_item').not('div.tabs_item:eq(' + index + ')').slideUp();
			tab.find('.tab_content').find('div.tabs_item:eq(' + index + ')').slideDown();
			g.preventDefault();
		});

		// FAQ Accordion JS
		$('.accordion').find('.accordion-title').on('click', function(){
			// Adds Active Class
			$(this).toggleClass('active');
			// Expand or Collapse This Panel
			$(this).next().slideToggle('fast');
			// Hide The Other Panels
			$('.accordion-content').not($(this).next()).slideUp('fast');
			// Removes Active Class From Other Titles
			$('.accordion-title').not($(this)).removeClass('active');		
		});

		$(".bar").each(function(){
			$(this).find(".bar-inner").animate({
			width: $(this).attr("data-width")
			},2000)
		});

		// Header Sticky, Go To Top JS
		$(window).on('scroll', function(){
			// Header Sticky JS
			if ($(this).scrollTop() >150){  
				$('.navbar-area').addClass("is-sticky");
			}
			else{
				$('.navbar-area').removeClass("is-sticky");
			};
		});

		// Go To Top JS
		$(window).on('scroll', function(){
			var scrolled = $(window).scrollTop();
			if (scrolled > 600) $('.go-top').addClass('active');
			if (scrolled < 600) $('.go-top').removeClass('active');
		});  
		$('.go-top').on('click', function() {
			$("html, body").animate({ scrollTop: "0" },  500);
		});

	})(window.jQuery);
}(jQuery));