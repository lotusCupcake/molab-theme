<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_features_area extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_features_area');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();

            $this->config->style = 1;
            $this->config->features_title1          = 'Expedite Learning';
            $this->config->features_content1        = 'Adopting fast learning techniques
            by real-world experts';
            $this->config->img1    = $CFG->wwwroot.'/theme/molab/pix/features/icon1.webp';

            $this->config->features_title2          = 'Open-source Platform';
            $this->config->features_content2        = 'The worlds learning open-source platform that helps your career';
            $this->config->img2    = $CFG->wwwroot.'/theme/molab/pix/features/icon2.webp';

            $this->config->features_title3          = 'Maximum Efficiency';
            $this->config->features_content3        = 'Learning from the course has the potential to achieve maximum efficiency';
            $this->config->img3    = $CFG->wwwroot.'/theme/molab/pix/features/icon3.webp';

            $this->config->left_shape_img    = $CFG->wwwroot.'/theme/molab/pix/human-3.webp';
            $this->config->right_shape_img    = $CFG->wwwroot.'/theme/molab/pix/new-additions.webp';
            $this->config->right_title      = 'New additions courses published each month';
            $this->config->right_content    = 'Choose from <span>25,000 +</span> online video courses';
        }
    }

    public function get_content() {
        global $CFG, $DB;

        $this->content         =  new stdClass;

        $features_number = 3;
        if(isset($this->config->features_number)){
            $features_number = $this->config->features_number;
        }

        $style = 1;
        if(isset($this->config->style)){
            $style = $this->config->style;
        }

        $text = '';
        if($style == 2):
            $text .='
            <div class="feature-area style-two">
                <div class="container">
                    <div class="feature-bg style-two">
                        <div class="row justify-content-center align-items-center">';
                            for($i = 1; $i <= $features_number; $i++) {
                                $img                    = 'img' . $i;
                                $features_title         = 'features_title' . $i;
                                $features_content       = 'features_content' . $i;

                                // Image
                                if(isset($this->config->$img)) { $img = $this->config->$img; }else{ $img = ''; }

                                // Title
                                if(isset($this->config->$features_title)) { $features_title = $this->config->$features_title; }else{ $features_title = ''; }

                                // Content
                                if(isset($this->config->$features_content)) { $features_content = $this->config->$features_content; }else{ $features_content = ''; }

                                $text .= '
                                <div class="col-xl-3 col-sm-6">
                                    <div class="single-feature color-style">
                                        <h3>';
                                        if($img):
                                            $text .= '<img src="'.molab_block_image_process($img).'" alt="'.$features_title.'">';
                                        endif;
                                        $text .= ' '.$features_title.'</h3>
                                        <p>'.$features_content.'</p>
                                    </div>
                                </div>';
                            } $text .= '

                            <div class="col-xl-3 col-sm-6">
                                <div class="new-additions style-two" data-speed="0.09" data-revert="true">
                                    <div class="new-brand">';
                                        if($this->config->right_shape_img):
                                            $text .= '<img src="'.molab_block_image_process($this->config->right_shape_img).'" alt="'.$this->config->right_title.'">';
                                        endif;
                                        $text .= '
                                    </div>
                                    <h6>'.$this->config->right_title.'</h6>
                                    <p>'.$this->config->right_content.'</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="humaaan-3">';
                    if($this->config->left_shape_img):
                        $text .= '<img src="'.molab_block_image_process($this->config->left_shape_img).'" alt="'.$this->config->right_title.'">';
                    endif;
                    $text .= '
                </div>
            </div>';
        else:
            $text .='
            <div class="feature-area bg-color-eee4dc pt-60 pb-30">
                <div class="container">
                    <div class="row justify-content-center">';
                        for($i = 1; $i <= $features_number; $i++) {
                            $img                    = 'img' . $i;
                            $features_title         = 'features_title' . $i;
                            $features_content       = 'features_content' . $i;

                            // Image
                            if(isset($this->config->$img)) { $img = $this->config->$img; }else{ $img = ''; }

                            // Title
                            if(isset($this->config->$features_title)) { $features_title = $this->config->$features_title; }else{ $features_title = ''; }

                            // Content
                            if(isset($this->config->$features_content)) { $features_content = $this->config->$features_content; }else{ $features_content = ''; }

                            $text .= '
                            <div class="col-lg-4 col-md-6">
                                <div class="single-feature">';
                                    if($img):
                                        $text .= '<img src="'.molab_block_image_process($img).'" alt="'.$features_title.'">';
                                    endif;
                                    $text .= '

                                    <h3>'.$features_title.'</h3>
                                    <p>'.$features_content.'</p>
                                </div>
                            </div>';
                        } $text .= '
                    </div>
                </div>
            </div>';
        endif;
        
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}