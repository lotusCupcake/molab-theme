<?php
global $CFG;
require_once($CFG->dirroot. '/theme/molab/inc/course_handler/molab_course_handler.php');

class block_molab_course_desc extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_course_desc');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
    }

    public function get_content() {
        global $CFG, $DB, $COURSE, $USER, $PAGE;

        $this->content         =  new stdClass;        

        $molabCourseHandler = new molabCourseHandler();
        $molabCourse = $molabCourseHandler->molabGetCourseDetails($COURSE->id);
        $molabCourseDescription = $molabCourseHandler->molabGetCourseDescription($COURSE->id, 99999999999999999999999);

        $molabCourseShortDescription = strip_tags($molabCourseHandler->molabGetCourseDescription($COURSE->id, 99999999999999));
        $molabCourseShortDescription = implode(' ', array_slice(str_word_count($molabCourseShortDescription, 2), 0, 15));

        // Get Teacher Name
        foreach($molabCourse->teachers as $teacher):
            $teacher = $teacher->name;
        endforeach;

        $text = '';

        $text .= '
        <div class="course-details-desc">
            <h3>'.$molabCourse->fullName.'</h3>
            <p>'.strip_tags($molabCourseShortDescription).'</p>
            <ul class="meta-list">
                <li>
                    <i class="ri-user-3-line"></i>
                    <span>'.$teacher.'</span>
                </li>
                <li>
                    <i class="ri-book-2-line"></i>
                    '.$molabCourse->enrolments.'
                </li>
                <li>
                    <i class="ri-user-2-line"></i> '. $molabCourse->molabRender->updatedDate .'
                </li>            
            </ul>';
            if($molabCourse->course_price) {
                $text .= '
                <div class="price">'.get_config('theme_molab', 'site_currency') .''.$molabCourse->course_price.'</div>';
            }else{
                $text .= '
                <div class="price">'.get_config('theme_molab', 'free_course_price') .'</div>';
            } $text .= '
        </div>
        
        <div class="courses-overview pt-75">
            '.$molabCourseDescription.'
        </div>';

        
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => false,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => false,
        );
    }

}