<?php
$string['pluginname'] = '[Molab] Course Details';
$string['molab_course_desc'] = '[Molab] Course Details';
$string['molab_course_desc:addinstance'] = 'Add a new [Molab] Course Details block';
$string['molab_course_desc:myaddinstance'] = 'Add a new [Molab] Course Details block';
