<?php
$string['pluginname'] = '[Molab] Banner Two';
$string['molab_banner_2'] = '[Molab] Banner Two';
$string['molab_banner_2:addinstance'] = 'Add a new [Molab] Banner block';
$string['molab_banner_2:myaddinstance'] = 'Add a new [Molab] Banner style 2 block';
$string['config_bottom_title'] = 'Banner Bottom Content';