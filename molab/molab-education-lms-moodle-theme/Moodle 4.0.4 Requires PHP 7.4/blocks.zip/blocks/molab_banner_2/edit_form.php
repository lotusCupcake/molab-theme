<?php

class block_molab_banner_2_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;
        $molabFontList = include($CFG->dirroot . '/theme/molab/inc/font_handler/molab_font_select.php');

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        // Top Title
        $mform->addElement('text', 'config_top_title', 'Banner Top Title');
        $mform->setDefault('config_top_title', 'FOR A BETTER FUTURE');
        $mform->setType('config_top_title', PARAM_RAW);

        // Title
        $mform->addElement('text', 'config_title', 'Banner Title');
        $mform->setDefault('config_title', 'A Course Is Essential For Building A <span>Career</span>');
        $mform->setType('config_title', PARAM_RAW);

        // Content
        $mform->addElement('textarea', 'config_body', get_string('config_body', 'theme_molab'), 'wrap="virtual" rows="6" cols="50"');
        $mform->setDefault('config_body', 'The experience of our instructors benefits your career');

        // Button Text
        $mform->addElement('text', 'config_btn', 'Button Text');
        $mform->setDefault('config_btn', 'Find Courses');
        $mform->setType('config_btn', PARAM_RAW);

        // Button Link
        $mform->addElement('text', 'config_button_link', 'Button Link');
        $mform->setDefault('config_button_link', $CFG->wwwroot . '/course');
        $mform->setType('config_button_link', PARAM_RAW);

        // Bottom Content
        $mform->addElement('text', 'config_bottom_title', get_string('config_bottom_title', 'block_molab_banner_2'));
        $mform->setDefault('config_bottom_title', '<h6>Total Online Student</h6><h3>125,000 +</h3>');
        $mform->setType('config_bottom_title', PARAM_RAW);

        // Section Image header title according to language file.
        $mform->addElement('header', 'config_image_heading', get_string('config_image_heading', 'theme_molab'));

        $mform->addElement('static', 'config_image_doc', '<b><a style="color: var(--main-color)" href="https://docs.envytheme.com/docs/molab-moodle-theme-documentation/faqs/how-to-get-the-image-url/" target="_blank">Doc link: How to make Image URL?</a></b>'); 

        // Banner Background Image
        $mform->addElement('text', 'config_banner_bg_img', 'Banner Background Image URL');
        $mform->setDefault('config_banner_bg_img', $CFG->wwwroot .'/theme/molab/pix/banner/banner-bg-2.webp');
        $mform->setType('config_banner_bg_img', PARAM_TEXT);

        // Banner Image
        $mform->addElement('text', 'config_banner_img', 'Banner Image URL');
        $mform->setDefault('config_banner_img', $CFG->wwwroot .'/theme/molab/pix/banner/banner-img-2.webp');
        $mform->setType('config_banner_img', PARAM_TEXT);

        // Bottom Content Image
        $mform->addElement('text', 'config_bottom_content_img', 'Bottom Content Icon Image URL');
        $mform->setDefault('config_bottom_content_img', $CFG->wwwroot .'/theme/molab/pix/banner/students.webp');
        $mform->setType('config_bottom_content_img', PARAM_TEXT);

        // Shape Image
        $mform->addElement('text', 'config_shape_image', 'Banner Shape Image URL');
        $mform->setDefault('config_shape_image', $CFG->wwwroot .'/theme/molab/pix/banner/banner-bg-shape.webp');
        $mform->setType('config_shape_image', PARAM_TEXT);
    }
}
