<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_contact_area2 extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_contact_area2');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->title        = 'Learn At Your Own Pace, With Lifetime Access Anywhere And Any Device';
            $this->config->section_img  = $CFG->wwwroot .'/theme/molab/pix/life-time.webp';
            $this->config->shape_img  = $CFG->wwwroot .'/theme/molab/pix/about-shape-1.webp';
        }
    }

    public function get_content() {
        global $CFG, $DB;

        $this->content  =  new stdClass;

        $text = '';
        $text .='
        <div class="lifetime-area ptb-100 bg-color-f2f7fa">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-lg-7">
						<div class="lifetime-content">
							<h2>'.$this->config->title.'</h2>';
                            if($this->config->section_img):
                                $text .= '
                                <img src="'.molab_block_image_process($this->config->section_img).'" alt="'.$this->config->title.'">';
                            endif;
                            $text .= '
						</div>
					</div>

					<div class="col-lg-5">
						<div class="register-now">
                            '.$this->config->contact_from_code.'
						</div>
					</div>
				</div>
			</div>';

            if($this->config->shape_img):
                $text .= '
                <img class="lifetime-shape" src="'.molab_block_image_process($this->config->shape_img).'" alt="'.$this->config->title.'">';
            endif;
            $text .= '
		</div>';
        
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}