<?php
$string['pluginname'] = '[Molab] Contact Area Two';
$string['molab_contact_area2'] = '[Molab] Contact Area Two';
$string['blocksettings'] = '[Molab] Contact Two Block Settings';
$string['molab_contact_area2:addinstance'] = 'Add a new [Molab] Contact Area Two block';
$string['molab_contact_area2:myaddinstance'] = 'Add a new [Molab] Contact Area Two block';