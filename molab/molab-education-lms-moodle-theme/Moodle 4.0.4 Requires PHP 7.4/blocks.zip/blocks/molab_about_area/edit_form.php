<?php
require_once($CFG->dirroot . '/theme/molab/inc/course_handler/molab_course_handler.php');

class block_molab_about_area_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;
        $molabFontList = include($CFG->dirroot . '/theme/molab/inc/font_handler/molab_font_select.php');

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        // Title
        $mform->addElement('text', 'config_title', get_string('config_title', 'theme_molab'));
        $mform->setDefault('config_title', 'We Share Knowledge Among The World');
        $mform->setType('config_title', PARAM_RAW);

        // Content
        $mform->addElement('textarea', 'config_content', 'Content');
        $mform->setDefault('config_content', 'Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Proin eget tortor risus. Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Sed porttitor lectus nibh. Donec quis ac lectus. Proin eget tortor risus. Sed porttitor lectus nibh. Praesent sapien massa, convallis risus. Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Sed porttitor lectus nibh. Donec');
        $mform->setType('config_content', PARAM_RAW);

        // Quote Content
        $mform->addElement('textarea', 'config_quote_content', 'Quote Content');
        $mform->setDefault('config_quote_content', 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Proin eget tortor risus. Sed porttitor lectus nibh. Praesent sapien massa. Quisque velit nisi, pretium ut lacinia in elementum id enim non nulla sit amet nisl tempus convallis quis ac lectus proin eget.');
        $mform->setType('config_quote_content', PARAM_RAW);

        // Name
        $mform->addElement('text', 'config_name', 'Name');
        $mform->setDefault('config_name', 'Lance Altman');
        $mform->setType('config_name', PARAM_RAW);

        // Designation
        $mform->addElement('text', 'config_designation', 'Designation');
        $mform->setDefault('config_designation', 'Lance Altman');
        $mform->setType('config_designation', PARAM_RAW);

        // Image URL
        $mform->addElement('static', 'config_image_doc', '<b><a style="color: var(--main-color)" href="https://docs.hibootstrap.com/docs/molab-moodle-theme-documentation/faqs/how-to-get-the-image-url/" target="_blank">Doc link: How to make Image URL?</a></b>'); 

        // Image
        $mform->addElement('text', 'config_img', 'Section Image URL');
        $mform->setDefault('config_img', $CFG->wwwroot .'/theme/molab/pix/about-img-2.webp');
        $mform->setType('config_img', PARAM_TEXT);

        // Shape Image 1
        $mform->addElement('text', 'config_shape_img', 'Quote Shape Image URL');
        $mform->setDefault('config_shape_img', $CFG->wwwroot .'/theme/molab/pix/quat-s.webp');
        $mform->setType('config_shape_img', PARAM_TEXT);

        // Shape Image 2
        $mform->addElement('text', 'config_shape_img2', 'Shape Image URL');
        $mform->setDefault('config_shape_img2', $CFG->wwwroot .'/theme/molab/pix/about-shape-1.webp');
        $mform->setType('config_shape_img2', PARAM_TEXT);

        $items = 3;
        if(isset($this->block->config->items)){
            $items = $this->block->config->items;
        }

        $items_range = array(
            0 => '0',
            1 => '1',
            2 => '2',
            3 => '3',
            4 => '4',
            5 => '5',
            6 => '6',
            7 => '7',
            8 => '8',
            9 => '9',
            10 => '10',
            11 => '11',
            12 => '12',
            13 => '13',
            14 => '14',
            15 => '15',
            16 => '16',
            17 => '17',
            18 => '18',
            19 => '19',
            20 => '20',
            21 => '21',
            22 => '22',
            23 => '23',
            24 => '24',
            25 => '25',
            26 => '26',
            27 => '27',
            28 => '28',
            29 => '29',
            30 => '30',
        );
        $items_max = 30;

        $mform->addElement('select', 'config_items', get_string('config_items', 'theme_molab'), $items_range);
        $mform->setDefault('config_items', 3);

        for($i = 1; $i <= $items; $i++) {
            $mform->addElement('header', 'config_molab_item' . $i , get_string('config_item', 'theme_molab') .' '. $i);

            // Title
            $mform->addElement('text', 'config_features_title' . $i, get_string('config_title', 'theme_molab', $i));
            $mform->setDefault('config_features_title' . $i, 'Who we are?');
            $mform->setType('config_features_title' . $i, PARAM_RAW);

            // Content
            $mform->addElement('textarea', 'config_features_content' . $i, 'Content '.$i );
            $mform->setDefault('config_features_content' . $i, '<p>Donec rutrum congue leo eget malesuada. Praesent massa, convallis a pellentesque egestas Curabitur , accumsan imperdiet et, porttitor at sem. Cras ultricies ligula sed magna dictum porta.</p>');
            $mform->setType('config_features_content' . $i, PARAM_RAW);

        }
    }
}
