<?php

class block_molab_faq_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;
        $molabFontList = include($CFG->dirroot . '/theme/molab/inc/font_handler/molab_font_select.php');

        $faqnumber = 5;
        if(isset($this->block->config->faqnumber)){
            $faqnumber = $this->block->config->faqnumber;
        }

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));
        
        // Title
        $mform->addElement('text', 'config_title', get_string('config_title', 'theme_molab'));
        $mform->setDefault('config_title', 'Frequently Asked Questions');
        $mform->setType('config_title', PARAM_RAW);

        $faqrange = array(
            1 => '1',
            2 => '2',
            3 => '3',
            4 => '4',
            5 => '5',
            6 => '6',
            7 => '7',
            8 => '8',
            9 => '9',
            10 => '10',
            11 => '11',
            12 => '12',
            13 => '13',
            14 => '14',
            15 => '15',
            16 => '16',
            17 => '17',
            18 => '18',
            19 => '19',
            20 => '20',
            21 => '21',
            22 => '22',
            23 => '23',
            24 => '24',
            25 => '25',
            26 => '26',
            27 => '27',
            28 => '28',
            29 => '29',
            30 => '30',
        );

        $mform->addElement('select', 'config_faqnumber', 'Faq Number', $faqrange);
        $mform->setDefault('config_faqnumber', 5);

        for($i = 1; $i <= $tabNumber; $i++) {
            $mform->addElement('header', 'config_molab_item_item' . $i , 'Tab Item ' . $i);

            $mform->addElement('text', 'config_item_title' . $i, 'Title' . $i);
            $mform->setDefault('config_item_title' . $i, 'How Do We Create Course Content?');
            $mform->setType('config_item_title' . $i, PARAM_TEXT);
        
            $mform->addElement('textarea', 'config_item_content' . $i, 'Faq Content' . $i, 'wrap="virtual" rows="10" cols="50"');
            $mform->setDefault('config_item_content' . $i, '
            Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula sed magna dictum porta. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel aliquet quam id dui posuere blandit Contact Us.');
            $mform->setType('config_item_content' . $i, PARAM_RAW);
        }

        // Image URL
        $mform->addElement('static', 'config_image_doc', '<b><a style="color: var(--main-color)" href="https://docs.hibootstrap.com/docs/molab-moodle-theme-documentation/faqs/how-to-get-the-image-url/" target="_blank">Doc link: How to make Image URL?</a></b>'); 

        // Image
        $mform->addElement('text', 'config_img', 'Section Image URL');
        $mform->setDefault('config_img', $CFG->wwwroot .'/theme/molab/pix/faq-img.webp');
        $mform->setType('config_img', PARAM_TEXT);
    }
}
