<?php
$string['pluginname'] = '[Molab] Blog Area';
$string['molab_blog_area'] = '[Molab] Blog Area';
$string['blocksettings'] = '[Molab] Blog Area Block Settings';
$string['molab_blog_area:addinstance'] = 'Add a new [Molab] Blog Area block';
$string['molab_blog_area:myaddinstance'] = 'Add a new [Molab] Blog Area block';