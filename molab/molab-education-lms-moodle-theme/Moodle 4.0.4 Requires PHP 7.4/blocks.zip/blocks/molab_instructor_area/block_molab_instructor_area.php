<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_instructor_area extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_instructor_area');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->style = 1;
            $this->config->title = 'These Are Our Instructor';
            $this->config->body = '<p>Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p><p>Proin eget tortor risus. Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Mauris blandit aliquet elit, egettincidunt nibh pulvinar ultricies ligula sed magna dictum porta.</p>';
            $this->config->btn = 'View All Instructors';
            $this->config->link = '#';

            $this->config->instructor_name1 = 'William James';
            $this->config->instructor_designation1 = 'Full Stack Developer';
            $this->config->instructor_img1 = $CFG->wwwroot.'/theme/molab/pix/instructors/instructors-1.webp';

            $this->config->instructor_name2 = 'Sally Welch';
            $this->config->instructor_designation2 = 'Art Director';
            $this->config->instructor_img2 = $CFG->wwwroot.'/theme/molab/pix/instructors/instructors-2.webp';

            $this->config->instructor_name3 = 'Willie Mcdonagh';
            $this->config->instructor_designation3 = 'Photographer';
            $this->config->instructor_img3 = $CFG->wwwroot.'/theme/molab/pix/instructors/instructors-3.webp';

            $this->config->instructor_name4 = 'Jesse Joslin';
            $this->config->instructor_designation4 = 'Content Strategist';
            $this->config->instructor_img4 = $CFG->wwwroot.'/theme/molab/pix/instructors/instructors-4.webp';

            $this->config->shape_img = $CFG->wwwroot.'/theme/molab/pix/instructors/instructors-shape-1.png';
            $this->config->shape_img2 = $CFG->wwwroot.'/theme/molab/pix/instructors/instructors-shape-2.png';
        }
    }

    public function get_content() {
        global $CFG, $DB;

        $this->content         =  new stdClass;

        $itemNumber = 4;
        if(isset($this->config->itemNumber)){
            $itemNumber = $this->config->itemNumber;
        }
       
        $style = 1;
        if(isset($this->config->style)){
            $style = $this->config->style;
        }

        $text = '';
        if($style == 3):
            $text .= '
            <div class="instructors-area pt-100 pb-70">
                <div class="container">
                    <div class="section-title left-title d-flex justify-content-between align-items-center">
                        <h2 class="mb-0">'.$this->config->title.'</h2>
                        '.$this->config->body.'';

                        if($this->config->btn):
                            $text .= '
                            <a href="'.$this->config->link.'" class="read-more">
                                '.$this->config->btn.'
                            </a>';
                        endif;
                        $text .= '
                    </div>

                    <div class="row justify-content-center">';
                        for($i = 1; $i <= $itemNumber; $i++) {
                            $instructor_name         = 'instructor_name' . $i;
                            $instructor_designation  = 'instructor_designation' . $i;
                            $instructor_img          = 'instructor_img' . $i;
                            $social_1_icon      = 'social_1_icon' . $i;
                            $social_1_link      = 'social_1_link' . $i;
                            $social_2_icon      = 'social_2_icon' . $i;
                            $social_2_link      = 'social_2_link' . $i;
                            $social_3_icon      = 'social_3_icon' . $i;
                            $social_3_link      = 'social_3_link' . $i;
                            $social_4_icon      = 'social_4_icon' . $i;
                            $social_4_link      = 'social_4_link' . $i;
                            $social_5_icon      = 'social_5_icon' . $i;
                            $social_5_link      = 'social_5_link' . $i;

                            if(isset($this->config->$social_1_icon)) { $social_1_icon = $this->config->$social_1_icon; }else{ $social_1_icon = ''; }
                            if(isset($this->config->$social_1_link)) { $social_1_link = $this->config->$social_1_link; }else{ $social_1_link = ''; }

                            if(isset($this->config->$social_2_icon)) { $social_2_icon = $this->config->$social_2_icon; }else{ $social_2_icon = ''; }
                            if(isset($this->config->$social_2_link)) { $social_2_link = $this->config->$social_2_link; }else{ $social_2_link = ''; }

                            if(isset($this->config->$social_3_icon)) { $social_3_icon = $this->config->$social_3_icon; }else{ $social_3_icon = ''; }
                            if(isset($this->config->$social_3_link)) { $social_3_link = $this->config->$social_3_link; }else{ $social_3_link = ''; }

                            if(isset($this->config->$social_4_icon)) { $social_4_icon = $this->config->$social_4_icon; }else{ $social_4_icon = ''; }
                            if(isset($this->config->$social_4_link)) { $social_4_link = $this->config->$social_4_link; }else{ $social_4_link = ''; }

                            if(isset($this->config->$social_5_icon)) { $social_5_icon = $this->config->$social_5_icon; }else{ $social_5_icon = ''; }
                            if(isset($this->config->$social_5_link)) { $social_5_link = $this->config->$social_5_link; }else{ $social_5_link = ''; }

                            if(isset($this->config->$instructor_name)) { $instructor_name = $this->config->$instructor_name; }else{ $instructor_name = ''; }

                            if(isset($this->config->$instructor_designation)) { $instructor_designation = $this->config->$instructor_designation; }else{ $instructor_designation = ''; }

                            if(isset($this->config->$instructor_img)) { $instructor_img = $this->config->$instructor_img; }else{ $instructor_img = ''; }

                            $text .= '
                            <div class="col-lg-3 col-sm-6">
                                <div class="single-instructors-item">
                                    <div class="instructors-img">';
                                        if($instructor_img):
                                            $text .= '
                                            <img src="'.molab_block_image_process($instructor_img).'" alt="'.$instructor_name.'">';
                                        endif;
                                        $text .= '

                                        <ul class="instructors-social">';
                                            if($social_1_icon):
                                                $text .= '
                                                <li><a href="'.$social_1_link.'" class="d-block" target="_blank"><i class="'.$social_1_icon.'"></i></a></li>';
                                            endif;

                                            if($social_2_icon):
                                                $text .= '
                                                <li><a href="'.$social_2_link.'" class="d-block" target="_blank"><i class="'.$social_2_icon.'"></i></a></li>';
                                            endif;

                                            if($social_3_icon):
                                                $text .= '
                                                <li><a href="'.$social_3_link.'" class="d-block" target="_blank"><i class="'.$social_3_icon.'"></i></a></li>';
                                            endif;

                                            if($social_4_icon):
                                                $text .= '
                                                <li><a href="'.$social_4_link.'" class="d-block" target="_blank"><i class="'.$social_4_icon.'"></i></a></li>';
                                            endif;

                                            if($social_5_icon):
                                                $text .= '
                                                <li><a href="'.$social_5_link.'" class="d-block" target="_blank"><i class="'.$social_5_icon.'"></i></a></li>';
                                            endif;
                                            $text .= '
                                        </ul>
                                    </div>

                                    <div class="instructors-content">
                                        <h3>'.$instructor_name.'</h3>
                                        <span>'.$instructor_designation.'</span>
                                    </div>
                                </div>
                            </div>';
                        } $text .= '
                    </div>
                </div>
            </div>';
        elseif($style == 2):
            $text .= '
            <div class="instructors-area ptb-100">
                <div class="container">
				    <div class="row justify-content-center">';
                        if($this->config->title || $this->config->body || $this->config->btn):
                            $text .= '
                            <div class="class="section-title left-title"">
                                <h2>'.$this->config->title.'</h2>
                                '.$this->config->body.'';
                                if($this->config->btn):
                                    $text .= '
                                    <a href="'.$this->config->link.'" class="default-btn">
                                        '.$this->config->btn.'
                                    </a>';
                                endif;
                                $text .= '
                            </div>';
                        endif;
                        
                        for($i = 1; $i <= $itemNumber; $i++) {
                            $instructor_name         = 'instructor_name' . $i;
                            $instructor_designation  = 'instructor_designation' . $i;
                            $instructor_img          = 'instructor_img' . $i;
                            $social_1_icon      = 'social_1_icon' . $i;
                            $social_1_link      = 'social_1_link' . $i;
                            $social_2_icon      = 'social_2_icon' . $i;
                            $social_2_link      = 'social_2_link' . $i;
                            $social_3_icon      = 'social_3_icon' . $i;
                            $social_3_link      = 'social_3_link' . $i;
                            $social_4_icon      = 'social_4_icon' . $i;
                            $social_4_link      = 'social_4_link' . $i;
                            $social_5_icon      = 'social_5_icon' . $i;
                            $social_5_link      = 'social_5_link' . $i;

                            if(isset($this->config->$social_1_icon)) { $social_1_icon = $this->config->$social_1_icon; }else{ $social_1_icon = ''; }
                            if(isset($this->config->$social_1_link)) { $social_1_link = $this->config->$social_1_link; }else{ $social_1_link = ''; }

                            if(isset($this->config->$social_2_icon)) { $social_2_icon = $this->config->$social_2_icon; }else{ $social_2_icon = ''; }
                            if(isset($this->config->$social_2_link)) { $social_2_link = $this->config->$social_2_link; }else{ $social_2_link = ''; }

                            if(isset($this->config->$social_3_icon)) { $social_3_icon = $this->config->$social_3_icon; }else{ $social_3_icon = ''; }
                            if(isset($this->config->$social_3_link)) { $social_3_link = $this->config->$social_3_link; }else{ $social_3_link = ''; }

                            if(isset($this->config->$social_4_icon)) { $social_4_icon = $this->config->$social_4_icon; }else{ $social_4_icon = ''; }
                            if(isset($this->config->$social_4_link)) { $social_4_link = $this->config->$social_4_link; }else{ $social_4_link = ''; }

                            if(isset($this->config->$social_5_icon)) { $social_5_icon = $this->config->$social_5_icon; }else{ $social_5_icon = ''; }
                            if(isset($this->config->$social_5_link)) { $social_5_link = $this->config->$social_5_link; }else{ $social_5_link = ''; }

                            if(isset($this->config->$instructor_name)) { $instructor_name = $this->config->$instructor_name; }else{ $instructor_name = ''; }

                            if(isset($this->config->$instructor_designation)) { $instructor_designation = $this->config->$instructor_designation; }else{ $instructor_designation = ''; }

                            if(isset($this->config->$instructor_img)) { $instructor_img = $this->config->$instructor_img; }else{ $instructor_img = ''; }

                            $text .= '
                            <div class="col-lg-4 col-sm-6">
                                <div class="single-instructors-item">
                                    <div class="instructors-img">';
                                        if($instructor_img):
                                            $text .= '
                                            <img src="'.molab_block_image_process($instructor_img).'" alt="'.$instructor_name.'">';
                                        endif;
                                        $text .= '

                                        <ul class="instructors-social">';
                                            if($social_1_icon):
                                                $text .= '
                                                <li><a href="'.$social_1_link.'" class="d-block" target="_blank"><i class="'.$social_1_icon.'"></i></a></li>';
                                            endif;

                                            if($social_2_icon):
                                                $text .= '
                                                <li><a href="'.$social_2_link.'" class="d-block" target="_blank"><i class="'.$social_2_icon.'"></i></a></li>';
                                            endif;

                                            if($social_3_icon):
                                                $text .= '
                                                <li><a href="'.$social_3_link.'" class="d-block" target="_blank"><i class="'.$social_3_icon.'"></i></a></li>';
                                            endif;

                                            if($social_4_icon):
                                                $text .= '
                                                <li><a href="'.$social_4_link.'" class="d-block" target="_blank"><i class="'.$social_4_icon.'"></i></a></li>';
                                            endif;

                                            if($social_5_icon):
                                                $text .= '
                                                <li><a href="'.$social_5_link.'" class="d-block" target="_blank"><i class="'.$social_5_icon.'"></i></a></li>';
                                            endif;
                                            $text .= '
                                        </ul>
                                    </div>

                                    <div class="instructors-content">
                                        <h3>'.$instructor_name.'</h3>
                                        <span>'.$instructor_designation.'</span>
                                    </div>
                                </div>
                            </div>';
                        } $text .= '
                    </div>
                </div>';

                if($this->config->shape_img):
                    $text .= '
                    <div class="instructors-shape-1" data-speed="0.09" data-revert="true">
                        <img src="'.molab_block_image_process($this->config->shape_img).'" alt="'.$this->config->title.'">
                    </div>';
                endif;

                if($this->config->shape_img2):
                    $text .= '
                    <div class="instructors-shape-2" data-speed="0.09" data-revert="true">
                        <img src="'.molab_block_image_process($this->config->shape_img2).'" alt="'.$this->config->title.'">
                    </div>';
                endif;
                $text .= '
            </div>';
        else:
            $text .= '
            <div class="instructors-area pt-130 pb-70">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="instructor-content">
                                <h2>'.$this->config->title.'</h2>
                                '.$this->config->body.'';
                                if($this->config->btn):
                                    $text .= '
                                    <a href="'.$this->config->link.'" class="default-btn">
                                        '.$this->config->btn.'
                                    </a>';
                                endif;
                                $text .= '
                            </div>
                        </div>
                        
                        <div class="col-lg-6">
                            <div class="row">';
                                for($i = 1; $i <= $itemNumber; $i++) {
                                    $instructor_name         = 'instructor_name' . $i;
                                    $instructor_designation  = 'instructor_designation' . $i;
                                    $instructor_img          = 'instructor_img' . $i;
                                    $social_1_icon      = 'social_1_icon' . $i;
                                    $social_1_link      = 'social_1_link' . $i;
                                    $social_2_icon      = 'social_2_icon' . $i;
                                    $social_2_link      = 'social_2_link' . $i;
                                    $social_3_icon      = 'social_3_icon' . $i;
                                    $social_3_link      = 'social_3_link' . $i;
                                    $social_4_icon      = 'social_4_icon' . $i;
                                    $social_4_link      = 'social_4_link' . $i;
                                    $social_5_icon      = 'social_5_icon' . $i;
                                    $social_5_link      = 'social_5_link' . $i;

                                    if(isset($this->config->$social_1_icon)) { $social_1_icon = $this->config->$social_1_icon; }else{ $social_1_icon = ''; }
                                    if(isset($this->config->$social_1_link)) { $social_1_link = $this->config->$social_1_link; }else{ $social_1_link = ''; }

                                    if(isset($this->config->$social_2_icon)) { $social_2_icon = $this->config->$social_2_icon; }else{ $social_2_icon = ''; }
                                    if(isset($this->config->$social_2_link)) { $social_2_link = $this->config->$social_2_link; }else{ $social_2_link = ''; }

                                    if(isset($this->config->$social_3_icon)) { $social_3_icon = $this->config->$social_3_icon; }else{ $social_3_icon = ''; }
                                    if(isset($this->config->$social_3_link)) { $social_3_link = $this->config->$social_3_link; }else{ $social_3_link = ''; }

                                    if(isset($this->config->$social_4_icon)) { $social_4_icon = $this->config->$social_4_icon; }else{ $social_4_icon = ''; }
                                    if(isset($this->config->$social_4_link)) { $social_4_link = $this->config->$social_4_link; }else{ $social_4_link = ''; }

                                    if(isset($this->config->$social_5_icon)) { $social_5_icon = $this->config->$social_5_icon; }else{ $social_5_icon = ''; }
                                    if(isset($this->config->$social_5_link)) { $social_5_link = $this->config->$social_5_link; }else{ $social_5_link = ''; }

                                    if(isset($this->config->$instructor_name)) { $instructor_name = $this->config->$instructor_name; }else{ $instructor_name = ''; }

                                    if(isset($this->config->$instructor_designation)) { $instructor_designation = $this->config->$instructor_designation; }else{ $instructor_designation = ''; }

                                    if(isset($this->config->$instructor_img)) { $instructor_img = $this->config->$instructor_img; }else{ $instructor_img = ''; }

                                    $text .= '
                                    <div class="col-lg-6 col-sm-6">';
                                        if ($i % 2 != 0) {
                                            $text .= '
                                            <div class="single-instructors-item mt-m-30">';
                                        }else{
                                            $text .= '
                                            <div class="single-instructors-item">';
                                        } $text .= '
                                            <div class="instructors-img">';
                                                if($instructor_img):
                                                    $text .= '
                                                    <img src="'.molab_block_image_process($instructor_img).'" alt="'.$instructor_name.'">';
                                                endif;
                                                $text .= '
        
                                                <ul class="instructors-social">';
                                                    if($social_1_icon):
                                                        $text .= '
                                                        <li><a href="'.$social_1_link.'" class="d-block" target="_blank"><i class="'.$social_1_icon.'"></i></a></li>';
                                                    endif;
        
                                                    if($social_2_icon):
                                                        $text .= '
                                                        <li><a href="'.$social_2_link.'" class="d-block" target="_blank"><i class="'.$social_2_icon.'"></i></a></li>';
                                                    endif;
        
                                                    if($social_3_icon):
                                                        $text .= '
                                                        <li><a href="'.$social_3_link.'" class="d-block" target="_blank"><i class="'.$social_3_icon.'"></i></a></li>';
                                                    endif;
        
                                                    if($social_4_icon):
                                                        $text .= '
                                                        <li><a href="'.$social_4_link.'" class="d-block" target="_blank"><i class="'.$social_4_icon.'"></i></a></li>';
                                                    endif;
        
                                                    if($social_5_icon):
                                                        $text .= '
                                                        <li><a href="'.$social_5_link.'" class="d-block" target="_blank"><i class="'.$social_5_icon.'"></i></a></li>';
                                                    endif;
                                                    $text .= '
                                                </ul>
                                            </div>
        
                                            <div class="instructors-content">
                                                <h3>'.$instructor_name.'</h3>
                                                <span>'.$instructor_designation.'</span>
                                            </div>
                                        </div>
                                    </div>';
                                } $text .= '

                            </div>
                        </div>
                    </div>
                </div>';

                if($this->config->shape_img):
                    $text .= '
                    <div class="instructors-shape-1" data-speed="0.09" data-revert="true">
                        <img src="'.molab_block_image_process($this->config->shape_img).'" alt="'.$this->config->title.'">
                    </div>';
                endif;

                if($this->config->shape_img2):
                    $text .= '
                    <div class="instructors-shape-2" data-speed="0.09" data-revert="true">
                        <img src="'.molab_block_image_process($this->config->shape_img2).'" alt="'.$this->config->title.'">
                    </div>';
                endif;
                $text .= '
            </div>';
        endif;

        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}