<?php

class block_molab_testimonial_area_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;

        $sliderNumber = 2;
        if(isset($this->block->config->sliderNumber)){
            $sliderNumber = $this->block->config->sliderNumber;
        }

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));
        
        // Class
        $mform->addElement('text', 'config_class', get_string('config_class', 'theme_molab'));
        $mform->setDefault('config_class', 'our-happy-student-area pb-100');
        $mform->setType('config_class', PARAM_RAW);

        $mform->addElement('select', 'config_style', get_string('config_style', 'theme_molab'), array(1 => 'Style 1', 2 => 'Style 2', 3 => 'Style 3'));
        $mform->setDefault('config_style', 1);

        // Title
        $mform->addElement('text', 'config_title', get_string('config_title', 'theme_molab'));
        $mform->setDefault('config_title', 'What Our Happy Student Say');
        $mform->setType('config_title', PARAM_RAW);

        // Button Text
        $mform->addElement('text', 'config_btn', 'Button Text');
        $mform->setDefault('config_btn', 'View All​');
        $mform->setType('config_btn', PARAM_RAW);

        // Button Link
        $mform->addElement('text', 'config_link', 'Button Link');
        $mform->setDefault('config_link', '#​');
        $mform->setType('config_link', PARAM_RAW);

        // Image URL
        $mform->addElement('static', 'config_image_doc', '<b><a style="color: var(--main-color)" href="https://docs.envytheme.com/docs/molab-moodle-theme-documentation/faqs/how-to-get-the-image-url/" target="_blank">Doc link: How to make Image URL?</a></b>'); 

        // Section Shape Image
        $mform->addElement('text', 'config_shape_img', 'Shape Image URL');        
        $mform->setDefault('config_shape_img', $CFG->wwwroot .'/theme/molab/pix/quat.png');
        $mform->setType('config_shape_img', PARAM_TEXT);

         // Section Shape Image
         $mform->addElement('text', 'config_shape_img2', 'Shape Image 2 URL(Style 3)');        
         $mform->setType('config_shape_img2', PARAM_TEXT);

        $sliderrange = array(
            1 => '1',
            2 => '2',
            3 => '3',
            4 => '4',
            5 => '5',
            6 => '6',
            7 => '7',
            8 => '8',
            9 => '9',
            10 => '10',
            11 => '11',
            12 => '12',
            13 => '13',
            14 => '14',
            15 => '15',
            16 => '16',
            17 => '17',
            18 => '18',
            19 => '19',
            20 => '20',
            21 => '21',
            22 => '22',
            23 => '23',
            24 => '24',
            25 => '25',
            26 => '26',
            27 => '27',
            28 => '28',
            29 => '29',
            30 => '30',
        );

        $mform->addElement('select', 'config_sliderNumber', get_string('config_items', 'theme_molab'), $sliderrange);
        $mform->setDefault('config_sliderNumber', 2);

        for($i = 1; $i <= $sliderNumber; $i++) {
            $mform->addElement('header', 'config_molab_item' . $i , get_string('config_item', 'theme_molab') . $i);

            $mform->addElement('text', 'config_img' . $i, 'Slider Image' . $i);
            if($i <= 2):
                $mform->setDefault('config_img' . $i, $CFG->wwwroot.'/theme/molab/pix/happy-student-'.$i.'.webp');
            else:
                $mform->setDefault('config_img' . $i, $CFG->wwwroot.'/theme/molab/pix/happy-student-1.webp');
            endif;
            $mform->setType('config_img' . $i, PARAM_TEXT);

            // Content
            $mform->addElement('textarea', 'config_slider_content' . $i, get_string('config_content', 'theme_molab', $i));
            $mform->setDefault('config_slider_content' . $i, '"Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla quis lorem ut libero malesuada feugiat."');
            $mform->setType('config_slider_content' . $i, PARAM_TEXT);

            // Name
            $mform->addElement('text', 'config_slider_name' . $i, ' Name', $i);
            $mform->setDefault('config_slider_name', 'James katliv');
            $mform->setType('config_slider_name' . $i, PARAM_TEXT);

            // Designation
            $mform->addElement('text', 'config_slider_designation' . $i, ' Designation', $i);
            $mform->setDefault('config_slider_designation', 'Student');
            $mform->setType('config_slider_designation' . $i, PARAM_TEXT);

            // Rating
            $mform->addElement('text', 'config_slider_rating' . $i, ' Rating Count(Style 2)', $i);
            $mform->setDefault('config_slider_rating', '5');
            $mform->setType('config_slider_rating' . $i, PARAM_TEXT);
        }
    }
}
