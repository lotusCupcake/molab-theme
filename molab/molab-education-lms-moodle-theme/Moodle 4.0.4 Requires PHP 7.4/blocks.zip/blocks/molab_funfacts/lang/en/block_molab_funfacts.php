<?php
$string['pluginname'] = '[Molab] Funfacts ';
$string['molab_funfacts'] = '[Molab] Funfacts ';
$string['blocksettings'] = '[Molab] Funfacts Block Settings';
$string['molab_funfacts:addinstance'] = 'Add a new [Molab] Funfacts block';
$string['molab_funfacts:myaddinstance'] = 'Add a new [Molab] Funfacts block';