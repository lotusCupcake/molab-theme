<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_funfacts extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_funfacts');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();

            $this->config->title = 'Our Achievements';
            $this->config->class = 'counter-area pt-70 pb-100';
            $this->config->body = 'Learn the secrets of life success, all the successes we have achieved in achieving goals.';

            $this->config->funfacts_title1  = 'Courses & Videos ';
            $this->config->funfacts_number1 = '25000';
            $this->config->funfacts_prefix1 = '+';

            $this->config->funfacts_title2  = 'Students Enrolled';
            $this->config->funfacts_number2 = '125000';
            $this->config->funfacts_prefix1 = '+';

            $this->config->funfacts_title3  = 'Courses Instructors';
            $this->config->funfacts_number3 = '10000';
            $this->config->funfacts_prefix1 = '+';

            $this->config->funfacts_title4  = 'Satisfaction Rate';
            $this->config->funfacts_number4 = '100';
            $this->config->funfacts_prefix1 = '%';

            $this->config->img = $CFG->wwwroot .'/theme/molab/pix/achievements-img.webp';
            $this->config->shape_img = $CFG->wwwroot .'/theme/molab/pix/counter-shape.webp';
        }
    }

    public function get_content() {
        global $CFG, $DB;

        $this->content         =  new stdClass;
        $funfactsnumber = 4;
        if(isset($this->config->funfactsnumber)){
            $funfactsnumber = $this->config->funfactsnumber;
        }
      
        $text = '';
        $text .= '
        <div class="'.$this->config->class.'">
			<div class="container">
				<div class="achievements">
					<div class="counter-bg p-70">
						<div class="row">';
                            for($i = 1; $i <= $funfactsnumber; $i++) {
                                $funfacts_title = 'funfacts_title' . $i;
                                $funfacts_number = 'funfacts_number' . $i;
                                $funfacts_prefix = 'funfacts_prefix' . $i;

                                if(isset($this->config->$funfacts_title)) {
                                    $funfacts_title = $this->config->$funfacts_title;
                                }else{
                                    $funfacts_title = '';
                                }
                                if(isset($this->config->$funfacts_number)) {
                                    $funfacts_number = $this->config->$funfacts_number;
                                }else{
                                    $funfacts_number = '';
                                }
                                if(isset($this->config->$funfacts_prefix)) {
                                    $funfacts_prefix = $this->config->$funfacts_prefix;
                                }else{
                                    $funfacts_prefix = '';                                
                                }
                                $text .= '
                                <div class="col-lg-3 col-sm-6">
                                    <div class="single-counter-item">
                                        <h2>
                                            <span class="odometer" data-count="'.$funfacts_number.'">00</span> 
                                            <span class="target">'.$funfacts_prefix.'</span>
                                        </h2>
                                        <h4>'.$funfacts_title.'</h4>
                                    </div>
                                </div>';
                            } $text .= '

						</div>
	
                        ';
                        if($this->config->shape_img):
                            $shape_img = $this->config->shape_img;
                            $text .= '
                            <div class="counter-shape" data-speed="0.09" data-revert="true">
                                <img src="'.molab_block_image_process($shape_img).'" alt="'.$this->config->title.'">						
                            </div>';
                        endif; 
                        $text .= '
					</div>
					<div class="achievements-contents" data-speed="0.09" data-revert="true">
						<h3>'.$this->config->title.'</h3>
						<p>'.$this->config->body.'</p>';
                        if($this->config->img):
                            $img = $this->config->img;
                            $text .= '<img src="'.molab_block_image_process($img).'" alt="'.$this->config->title.'">';
                        endif; 
                        $text .= '
					</div>
				</div>
			</div>
		</div>';
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}