<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_cta extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_cta');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->title    = 'Learn at your own pace, with lifetime access anywhere and any device';
            $this->config->class    = 'get-started-area pb-100';
            $this->config->btn      = 'Get Started';
            $this->config->link     = '#';
            $this->config->img      = $CFG->wwwroot .'/theme/molab/pix/humaaan-6.webp';
            $this->config->shape_img      = $CFG->wwwroot .'/theme/molab/pix/get-shape.webp';
            $this->config->style = 1;
        }
    }

    public function get_content() {
        global $CFG, $DB;

        $this->content         =  new stdClass;
        
        $style = 1;
        if(isset($this->config->style)){
            $style = $this->config->style;
        }
        $text = '';

        if($style == 3):
            $text .= '
            <div class="'.$this->config->class.'">
                <div class="container">
				    <div class="get-started-bg style-three">
                        <div class="row align-items-center">
						    <div class="col-lg-7">
                                '.$this->config->title.'
                            </div>
                            <div class="col-lg-5">
                                <div class="get-started-btn">';
                                    if($this->config->btn):
                                        $text .= '
                                        <a href="'.$this->config->link.'" class="default-btn">
                                            '.$this->config->btn.'
                                        </a>';
                                    endif;
                                    $text .= '
                                </div>
                            </div>
                        </div>

                        <div class="humaaan-4 humaaan-5">';
                            if($this->config->img):
                                $img = $this->config->img;
                                $text .= '<img src="'.molab_block_image_process($img).'" alt="'.$this->config->title.'">';
                            endif; 
                            $text .= '
                        </div>';

                        if($this->config->shape_img):
                            $shape_img = $this->config->shape_img;
                            $text .= '<img class="get-shape-img" src="'.molab_block_image_process($shape_img).'" alt="'.$this->config->title.'">';
                        endif; 
                        $text .= '
                    </div>
                </div>
            </div>';
        elseif($style == 2):
            $text .= '
            <div class="'.$this->config->class.'">
                <div class="container">
				    <div class="get-started-bg style-two">
                        <div class="row align-items-center">
						    <div class="col-lg-7">
                                '.$this->config->title.'
                            </div>
                            <div class="col-lg-5">
                                <div class="get-started-btn">';
                                    if($this->config->btn):
                                        $text .= '
                                        <a href="'.$this->config->link.'" class="default-btn">
                                            '.$this->config->btn.'
                                        </a>';
                                    endif;
                                    $text .= '
                                </div>
                            </div>
                        </div>

                        <div class="humaaan-4 humaaan-5">';
                            if($this->config->img):
                                $img = $this->config->img;
                                $text .= '<img src="'.molab_block_image_process($img).'" alt="'.$this->config->title.'">';
                            endif; 
                            $text .= '
                        </div>';

                        if($this->config->shape_img):
                            $shape_img = $this->config->shape_img;
                            $text .= '<img class="get-shape-img" src="'.molab_block_image_process($shape_img).'" alt="'.$this->config->title.'">';
                        endif; 
                        $text .= '
                    </div>
                </div>
            </div>';
        else:
            $text .= '
            <div class="'.$this->config->class.'">
                <div class="container">
                    <div class="get-started-bg">
                        <div class="row align-items-center">
                            <div class="col-lg-8">
                                <h2>'.$this->config->title.'</h2>
                            </div>
                            <div class="col-lg-4">
                                <div class="get-started-btn">';
                                    if($this->config->btn):
                                        $text .= '
                                        <a href="'.$this->config->link.'" class="default-btn">
                                            '.$this->config->btn.'
                                        </a>';
                                    endif;
                                    $text .= '
                                </div>
                            </div>
                        </div>

                        <div class="humaaan-4">';
                            if($this->config->img):
                                $img = $this->config->img;
                                $text .= '<img src="'.molab_block_image_process($img).'" alt="'.$this->config->title.'">';
                            endif; 
                            $text .= '
                        </div>
                    </div>
                </div>
            </div>';
        endif;
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}