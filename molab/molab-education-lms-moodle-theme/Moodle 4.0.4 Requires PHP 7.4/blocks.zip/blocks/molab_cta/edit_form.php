<?php

class block_molab_cta_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        // Class
        $mform->addElement('text', 'config_class', get_string('config_class', 'theme_molab'));
        $mform->setDefault('config_class', 'get-started-area pb-100');
        $mform->setType('config_class', PARAM_RAW);

        $mform->addElement('select', 'config_style', get_string('config_style', 'theme_molab'), array(1 => 'Style 1', 2 => 'Style 2', 3 => 'Style 3'));
        $mform->setDefault('config_style', 1);

        // Title
        $mform->addElement('text', 'config_title', get_string('config_title', 'theme_molab'));
        $mform->setDefault('config_title', 'Learn at your own pace, with lifetime access anywhere and any device');
        $mform->setType('config_title', PARAM_RAW);

        // Button Text
        $mform->addElement('text', 'config_btn', 'Button Text');
        $mform->setDefault('config_btn', 'Get Started​');
        $mform->setType('config_btn', PARAM_RAW);

        // Button Link
        $mform->addElement('text', 'config_link', 'Button Link');
        $mform->setDefault('config_link', '#​');
        $mform->setType('config_link', PARAM_RAW);

        // Image URL
        $mform->addElement('static', 'config_image_doc', '<b><a style="color: var(--main-color)" href="https://docs.envytheme.com/docs/molab-moodle-theme-documentation/faqs/how-to-get-the-image-url/" target="_blank">Doc link: How to make Image URL?</a></b>'); 

        $mform->addElement('text', 'config_img', 'Section Image 1 URL(Image recommended size 167X262)');
        $mform->setDefault('config_img', $CFG->wwwroot .'/theme/molab/pix/humaaan-6.webp');
        $mform->setType('config_img', PARAM_TEXT);

        $mform->addElement('text', 'config_shape_img', 'Shape Image URL(For Style 2)');
        $mform->setDefault('config_shape_img', $CFG->wwwroot .'/theme/molab/pix/get-shape.webp');
        $mform->setType('config_shape_img', PARAM_TEXT);
    }
}
