<?php
$string['pluginname'] = '[Molab] Course Enrolment Custom';
$string['molab_course_enrl'] = '[Molab] Course Enrolment Custom';
$string['molab_course_enrl:addinstance'] = 'Add a new course Enrolment Custom block';
$string['molab_course_enrl:myaddinstance'] = 'Course Enrolment Custom block';

$string['config_item_title'] = 'Item title';
$string['config_item_value'] = 'Item title value';
$string['config_item_icon'] = 'Item icon';
$string['config_items'] = 'Number of items';
$string['course_enrolment'] = 'Buy & Enrol Now';

$string['course_enrolled'] = 'You\'re enrolled';
$string['course_enrolled_text'] = 'You are currently enrolled in this course.';
$string['course_price'] = 'Price';
$string['course_currency'] = '$';