<?php
$string['pluginname'] = '[Molab] Gallery';
$string['molab_gallery'] = '[Molab] Gallery';
$string['molab_gallery:addinstance'] = 'Add a new [Molab] Gallery block';
$string['molab_gallery:myaddinstance'] = 'Add a new [Molab] Gallery block';
$string['config_image'] = 'Gallery Images';
$string['config_gallery_btn'] = 'Gallery Button Text';
$string['config_gallery_btn_link'] = 'Gallery Button Link';