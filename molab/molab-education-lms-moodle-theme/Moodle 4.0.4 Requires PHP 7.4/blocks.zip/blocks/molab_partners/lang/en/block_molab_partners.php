<?php
$string['pluginname'] = '[Molab] Partners';
$string['molab_partners'] = '[Molab] Partners';
$string['molab_partners:addinstance'] = 'Add a new [Molab] Partners block';
$string['molab_partners:myaddinstance'] = 'Add a new [Molab] Partners block';
$string['config_image'] = 'Partner Images';
$string['config_partners_btn'] = 'Partners Button Text';
$string['config_partners_btn_link'] = 'Partners Button Link';