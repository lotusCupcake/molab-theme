<?php
global $CFG;
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
class block_molab_newsletter extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_newsletter');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->class = 'join-our-community-area ptb-100';
            $this->config->title = 'Join Our Community';
            $this->config->body = 'Stay ahead of the game and stay informed with our latest news and exclusive offers. Sign up for our newsletter now and get it all delivered straight to your inbox.';
            $this->config->placeholder = 'Email address';
            $this->config->btn = 'Subscribe';
            $this->config->action_url = '';
            $this->config->img = $CFG->wwwroot .'/theme/molab/pix/community-shape-1.webp';
            $this->config->shape_img = $CFG->wwwroot .'/theme/molab/pix/community-shape-2.webp';
            $this->config->style = 1;
        }
    }

    public function get_content() {
        global $CFG, $DB, $COURSE, $USER, $PAGE;

        $this->content         =  new stdClass;
        $style = 1;
        if(isset($this->config->style)){
            $style = $this->config->style;
        }

        $text = '';
        if($style == 2):
            $text .= '
            <div class="'.$this->config->class.'">
                <div class="container">
                    <div class="our-community-content style-three">
                        <h2>'. $this->config->title .'</h2>
                        <p>'.$this->config->body.'</p>';
                        if($this->config->action_url):
                            $text .= '
                            <form action="'.$this->config->action_url.'" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="newsletter-form validate" target="_blank">
                                <div class="d-flex align-items-center">
                                    <input type="text" value="" name="EMAIL" class="email input-newsletter form-control" id="mce-EMAIL" placeholder="'.$this->config->placeholder.'" required>
                                    <button type="submit" name="subscribe" id="mc-embedded-subscribe" class="button default-btn">'.$this->config->btn.'</button>
                                </div>
                            </form>';
                        endif;
                        $text .= '
                    </div>
                </div>';
                if($this->config->shape_img):
                    $shape_img = $this->config->shape_img;
                    $text .= '
                    <div class="shape community-shape-2" data-speed="0.09" data-revert="true">
                        <img src="'.molab_block_image_process($shape_img).'" alt="'.$this->config->title.'">
                    </div>';
                endif;
                if($this->config->img):
                    $img = $this->config->img;
                    $text .= '
                    <div class="shape community-shape-3" data-speed="0.09" data-revert="true">
                        <img src="'.molab_block_image_process($img).'" alt="'.$this->config->title.'">
                    </div>';
                endif;
                $text .= '
            </div>';
        else:
            $text .= '
            <div class="'.$this->config->class.'">
                <div class="container">
                    <div class="our-community-bg">
                        <div class="our-community-content">
                            <h2>'. $this->config->title .'</h2>
                            <p>'.$this->config->body.'</p>';
                            if($this->config->action_url):
                                $text .= '
                                <form action="'.$this->config->action_url.'" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="newsletter-form validate" target="_blank">
                                    <div class="d-flex align-items-center">
                                        <input type="text" value="" name="EMAIL" class="email input-newsletter form-control" id="mce-EMAIL" placeholder="'.$this->config->placeholder.'" required>
                                        <button type="submit" name="subscribe" id="mc-embedded-subscribe" class="button default-btn">'.$this->config->btn.'</button>
                                    </div>
                                </form>';
                            endif;
                            $text .= '
                        </div>';
                        if($this->config->img):
                            $img = $this->config->img;
                            $text .= '
                            <div class="community-shape-1" data-speed="0.09" data-revert="true">
                                <img src="'.molab_block_image_process($img).'" alt="'.$this->config->title.'">
                            </div>';
                        endif;

                        if($this->config->shape_img):
                            $shape_img = $this->config->shape_img;
                            $text .= '
                            <div class="community-shape-2" data-speed="0.09" data-revert="true">
                                <img src="'.molab_block_image_process($shape_img).'" alt="'.$this->config->title.'">
                            </div>';
                        endif;
                        $text .= '
                    </div>
                </div>
            </div>';
        endif;
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}