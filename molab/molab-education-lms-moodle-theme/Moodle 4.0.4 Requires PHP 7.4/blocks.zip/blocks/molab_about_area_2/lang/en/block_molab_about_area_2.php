<?php
$string['pluginname'] = '[Molab] About Area Two';
$string['molab_about_area_2'] = '[Molab] About Area Two';
$string['molab_about_area_2:addinstance'] = 'Add a new [Molab] About Area block';
$string['molab_about_area_2:myaddinstance'] = 'Add a new [Molab] About Area style 2 block';