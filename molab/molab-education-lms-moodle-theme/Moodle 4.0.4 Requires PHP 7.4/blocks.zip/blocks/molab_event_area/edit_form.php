<?php

class block_molab_event_area_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;
        $molabFontList = include($CFG->dirroot . '/theme/molab/inc/font_handler/molab_font_select.php');
        require_once($CFG->dirroot . '/theme/molab/inc/event_handler/event_handler.php');
        include_once($CFG->dirroot . '/course/lib.php');
        require_once($CFG->dirroot. '/course/renderer.php');

        $molabEventHandler = new molabEventHandler();
        $molabEventList = $molabEventHandler->molabEventList();

        $searchareas = \core_search\manager::get_search_areas_list(true);
        $areanames = array();
        foreach ($molabEventList as $k => $molabEvent) {
            $areanames[$k] = $molabEvent->name;

        }

        $items = 4;
        if(isset($this->block->config->items)){
            $items = $this->block->config->items;
        }

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        // Class
        $mform->addElement('text', 'config_class', get_string('config_class', 'theme_molab'));
        $mform->setDefault('config_class', 'events-area overflow-hidden bg-color-fdfcfc pt-100 pb-70');
        $mform->setType('config_class', PARAM_RAW);

        $mform->addElement('select', 'config_style', get_string('config_style', 'theme_molab'), array(1 => 'Style 1', 2 => 'Style 2'));
        $mform->setDefault('config_style', 1);

        // Title
        $mform->addElement('text', 'config_title', get_string('config_title', 'theme_molab'));
        $mform->setDefault('config_title', 'Upcoming Events Schedule');
        $mform->setType('config_title', PARAM_RAW);

        // Content
        $mform->addElement('text', 'config_content', 'Content(Style 2)');
        $mform->setType('config_content', PARAM_RAW);

        // Button Text
        $mform->addElement('text', 'config_btn', 'Button TextStyle 2)');
        $mform->setDefault('config_btn', 'View All​');
        $mform->setType('config_btn', PARAM_RAW);

        // Button Link
        $mform->addElement('text', 'config_link', 'Button LinkStyle 2)');
        $mform->setDefault('config_link', '#​');
        $mform->setType('config_link', PARAM_RAW);

        $itemRange = array(
            1 => '1',
            2 => '2',
            3 => '3',
            4 => '4',
            5 => '5',
            6 => '6',
            7 => '7',
            8 => '8',
            9 => '9',
            10 => '10',
            11 => '11',
            12 => '12',
            13 => '13',
            14 => '14',
            15 => '15',
            16 => '16',
            17 => '17',
            18 => '18',
            19 => '19',
            20 => '20',
            21 => '21',
            22 => '22',
            23 => '23',
            24 => '24',
            25 => '25',
            26 => '26',
            27 => '27',
            28 => '28',
            29 => '29',
            30 => '30',
        );

        $mform->addElement('select', 'config_items', get_string('config_items', 'theme_molab'), $itemRange);
        $mform->setDefault('config_items', 4);

        $mform->addElement('text', 'config_location_title', 'Location Label Title');
        $mform->setDefault('config_location_title', 'Location');
        $mform->setType('config_location_title', PARAM_TEXT);

        for($i = 1; $i <= $items; $i++) {
            $mform->addElement('header', 'config_molab_item' . $i , get_string('config_item', 'theme_molab') . $i);

            $options = array(
                'multiple' => false,
                'noselectionstring' => 'Please select an item from the dropdown below.',
            );
            $mform->addElement('autocomplete', 'config_event' . $i, 'Event', $areanames, $options);
            $mform->addRule('config_event' . $i, get_string('required'), 'required', null, 'client', false, false);

            $mform->addElement('text', 'config_event_link' . $i, 'Event Link' . $i);
            $mform->setDefault('config_event_link' . $i, '#');
            $mform->setType('config_event_link' . $i, PARAM_TEXT);
        }

        // Image URL
        $mform->addElement('static', 'config_image_doc', '<b><a style="color: var(--main-color)" href="https://docs.envytheme.com/docs/molab-moodle-theme-documentation/faqs/how-to-get-the-image-url/" target="_blank">Doc link: How to make Image URL?</a></b>'); 

        $mform->addElement('text', 'config_img', 'Section Image 1 URL(Image recommended size 396X569)');
        $mform->setDefault('config_img', $CFG->wwwroot .'/theme/molab/pix/event-img-1.webp');
        $mform->setType('config_img', PARAM_TEXT);

        $mform->addElement('text', 'config_shape_img', 'Shape Image URL');
        $mform->setDefault('config_shape_img', $CFG->wwwroot .'/theme/molab/pix/missing.svg');
        $mform->setType('config_shape_img', PARAM_TEXT);
    }
}
