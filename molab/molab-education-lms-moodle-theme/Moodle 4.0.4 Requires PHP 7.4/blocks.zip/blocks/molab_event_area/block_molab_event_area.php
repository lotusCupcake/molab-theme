<?php
global $CFG;

include_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->dirroot. '/course/renderer.php');
require_once($CFG->dirroot . '/theme/molab/inc/event_handler/event_handler.php');
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');

class block_molab_event_area extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_event_area');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $molabEventHandler = new molabEventHandler();
            $molabEventList = $molabEventHandler->molabGetExampleEventIds(6);
            $this->config = new \stdClass();
            $this->config->items = 4;
            $this->config->title = 'Upcoming Events Schedule';
            $this->config->class = 'events-area overflow-hidden bg-color-fdfcfc pt-100';
            $this->config->location_title  = 'Location';
            $this->config->img = $CFG->wwwroot .'/theme/molab/pix/event-img-1.webp';
            $this->config->shape_img = $CFG->wwwroot .'/theme/molab/pix/missing.svg';
            $this->config->style = 1;
        }
    }

    public function get_content() {
        global $CFG, $DB;

        $this->content         =  new stdClass;
        $items = 4;
        if(isset($this->config->items)){
            $items = $this->config->items;
        }
        
        $style = 1;
        if(isset($this->config->style)){
            $style = $this->config->style;
        }
      
        $text = '';
        if($style == 2):
            $text .='
            <div class="'.$this->config->class.'">
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-8">
                            <div class="events-wraps">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="row">';
                                            for($i = 1; $i <= $items; $i++) {
                                                if ($i % 2 != 0) {
                                                    $event_link = 'event_link' . $i;
                                                    $event      = 'event' . $i;

                                                    if(isset($this->config->$content)) {
                                                        $content = $this->config->$content;
                                                    }else{
                                                        $content = '';
                                                    }
                                                    
                                                    if ($DB->record_exists('event', array('id' => $this->config->$event))) {
                                                        $molabEventHandler = new molabEventHandler();
                                                        $molabGetEvent = $molabEventHandler->molabGetEvent((int)$this->config->$event);
                                                        $text .= '
                                                        <div class="col-lg-12 col-sm-6">';
                                                            if ($i == 1):
                                                                $text .= '<div class="single-events-item bg-color mt-m-30">';
                                                            else:
                                                                $text .= '<div class="single-events-item bg-color">';
                                                            endif;
                                                            $text .= '
                                                                <h3>
                                                                    <a href="'.$this->config->$event_link.'">
                                                                    '.$molabGetEvent->name.'
                                                                    </a>
                                                                </h3>
                            
                                                                <div class="events-content">
                                                                    <div class="events-date">
                                                                        <span class="date">'.$molabGetEvent->dateDay.' '.$molabGetEvent->dateMonth.'</span>
                                                                        <span class="year">'.$molabGetEvent->dateYear.'</span>
                                                                    </div>
                                                                    
                                                                    <ul>
                                                                        <li>
                                                                            <h6>'.$this->config->location_title.'</h6>
                                                                            <p>'.$molabGetEvent->location.'</p>
                                                                        </li>
                                                                        <li>
                                                                            '.$molabGetEvent->description.'
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>';
                                                    }
                                                }
                                            } $text .= '
                                        </div>
                                    </div>
                
                                    <div class="col-lg-6">
                                        <div class="row">';
                                            for($i = 1; $i <= $items; $i++) {
                                                if ($i % 2 == 0) {
                                                    $event_link = 'event_link' . $i;
                                                    $event      = 'event' . $i;
                
                                                    if(isset($this->config->$content)) {
                                                        $content = $this->config->$content;
                                                    }else{
                                                        $content = '';
                                                    }
                                                    
                                                    if ($DB->record_exists('event', array('id' => $this->config->$event))) {
                                                        $molabEventHandler = new molabEventHandler();
                                                        $molabGetEvent = $molabEventHandler->molabGetEvent((int)$this->config->$event);
                                                        $text .= '
                                                        <div class="col-lg-12 col-sm-6">
                                                            <div class="single-events-item bg-color">
                                                                <h3>
                                                                    <a href="'.$event_link.'">
                                                                    '.$molabGetEvent->name.'
                                                                    </a>
                                                                </h3>
                            
                                                                <div class="events-content">
                                                                    <div class="events-date">
                                                                        <span class="date">'.$molabGetEvent->dateDay.' '.$molabGetEvent->dateMonth.'</span>
                                                                        <span class="year">'.$molabGetEvent->dateYear.'</span>
                                                                    </div>
                                                                    
                                                                    <ul>
                                                                        <li>
                                                                            <h6>'.$this->config->location_title.'</h6>
                                                                            <p>'.$molabGetEvent->location.'</p>
                                                                        </li>
                                                                        <li>
                                                                            '.$molabGetEvent->description.'
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>';
                                                    }
                                                }
                                            } $text .= '
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="event-content pl-15">
                                <h2>'.$this->config->title.'</h2>
                                <p>'.$this->config->content.'</p>';
                                if($this->config->btn):
                                    $text .= '
                                    <a href="'.$this->config->link.'" class="default-btn">
                                        '.$this->config->btn.'
                                    </a>';
                                endif;
                                $text .= '
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        else:
            $text .= '
            <div class="'.$this->config->class.'">
                <div class="container">
                    <div class="section-title">
                        <h2>'.$this->config->title.'</h2>
                    </div>

                    <div class="row align-items-center justify-content-center">
                        <div class="col-xl-3">
                            <div class="row">';
                                for($i = 1; $i <= $items; $i++) {
                                    if ($i % 2 != 0) {
                                        $event_link = 'event_link' . $i;
                                        $event      = 'event' . $i;

                                        if(isset($this->config->$content)) {
                                            $content = $this->config->$content;
                                        }else{
                                            $content = '';
                                        }
                                        
                                        if ($DB->record_exists('event', array('id' => $this->config->$event))) {
                                            $molabEventHandler = new molabEventHandler();
                                            $molabGetEvent = $molabEventHandler->molabGetEvent((int)$this->config->$event);
                                            $text .= '
                                            <div class="col-lg-12 col-sm-6">
                                                <div class="single-events-item">
                                                    <h3>
                                                        <a href="'.$this->config->$event_link.'">
                                                        '.$molabGetEvent->name.'
                                                        </a>
                                                    </h3>
                
                                                    <div class="events-content">
                                                        <div class="events-date">
                                                            <span class="date">'.$molabGetEvent->dateDay.' '.$molabGetEvent->dateMonth.'</span>
                                                            <span class="year">'.$molabGetEvent->dateYear.'</span>
                                                        </div>
                                                        
                                                        <ul>
                                                            <li>
                                                                <h6>'.$this->config->location_title.'</h6>
                                                                <p>'.$molabGetEvent->location.'</p>
                                                            </li>
                                                            <li>
                                                                '.$molabGetEvent->description.'
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>';
                                        }
                                    }
                                } $text .= '
                            </div>
                        </div>

                        <div class="col-xl-6">
                            <div class="event-img">';
                                if($this->config->img):
                                    $text .= '<img src="'.molab_block_image_process($this->config->img).'" alt="'.$this->config->title.'">';
                                endif; 
                                if($this->config->shape_img):
                                    $text .= '<img class="dont-mising" src="'.molab_block_image_process($this->config->shape_img).'" alt="'.$this->config->title.'">';
                                endif; 
                                $text .= '
                            </div>
                        </div>

                        <div class="col-xl-3">
                            <div class="row">';
                            for($i = 1; $i <= $items; $i++) {
                                if ($i % 2 == 0) {
                                    $event_link = 'event_link' . $i;
                                    $event      = 'event' . $i;

                                    if(isset($this->config->$content)) {
                                        $content = $this->config->$content;
                                    }else{
                                        $content = '';
                                    }
                                    
                                    if ($DB->record_exists('event', array('id' => $this->config->$event))) {
                                        $molabEventHandler = new molabEventHandler();
                                        $molabGetEvent = $molabEventHandler->molabGetEvent((int)$this->config->$event);
                                        $text .= '
                                        <div class="col-lg-12 col-sm-6">
                                            <div class="single-events-item">
                                                <h3>
                                                    <a href="'.$event_link.'">
                                                    '.$molabGetEvent->name.'
                                                    </a>
                                                </h3>
            
                                                <div class="events-content">
                                                    <div class="events-date">
                                                        <span class="date">'.$molabGetEvent->dateDay.' '.$molabGetEvent->dateMonth.'</span>
                                                        <span class="year">'.$molabGetEvent->dateYear.'</span>
                                                    </div>
                                                    
                                                    <ul>
                                                        <li>
                                                            <h6>'.$this->config->location_title.'</h6>
                                                            <p>'.$molabGetEvent->location.'</p>
                                                        </li>
                                                        <li>
                                                            '.$molabGetEvent->description.'
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>';
                                    }
                                }
                            } $text .= '
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        endif;
        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}