<?php
$string['pluginname'] = '[Molab] Event Area';
$string['molab_event_area'] = '[Molab] Event Area ';
$string['blocksettings'] = '[Molab] Event Area Block Settings';
$string['molab_event_area:addinstance'] = 'Add a new [Molab] Event Area block';
$string['molab_event_area:myaddinstance'] = 'Add a new [Molab] Event Area block';