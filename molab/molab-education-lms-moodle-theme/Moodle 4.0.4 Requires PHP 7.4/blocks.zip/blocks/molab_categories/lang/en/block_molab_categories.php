<?php
$string['pluginname'] = '[Molab] Categories Area';
$string['molab_categories'] = '[Molab] Categories Area';
$string['blocksettings'] = '[Molab] Categories Area Block Settings';
$string['molab_categories:addinstance'] = 'Add a new [Molab] Categories Area block';
$string['molab_categories:myaddinstance'] = 'Add a new [Molab] Categories Area block';