<?php
require_once($CFG->dirroot . '/theme/molab/inc/course_handler/molab_course_handler.php');

class block_molab_categories_edit_form extends block_edit_form {

    protected function specific_definition($mform) {

        global $CFG;
        $molabFontList = include($CFG->dirroot . '/theme/molab/inc/font_handler/molab_font_select.php');
        $molabCourseHandler = new molabCourseHandler();
        $molabCourseCategories = $molabCourseHandler->molabListCategories();

        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));

        // Class
        $mform->addElement('text', 'config_class', get_string('config_class', 'theme_molab'));
        $mform->setDefault('config_class', 'categories-area pt-100 pb-70');
        $mform->setType('config_class', PARAM_RAW);

        // Title
        $mform->addElement('text', 'config_title', get_string('config_title', 'theme_molab'));
        $mform->setDefault('config_title', 'Explore The Categories');
        $mform->setType('config_title', PARAM_RAW);

        $items = 5;
        if(isset($this->block->config->items)){
            $items = $this->block->config->items;
        }

        $items_range = array(
            1 => '1',
            2 => '2',
            3 => '3',
            4 => '4',
            5 => '5',
            6 => '6',
            7 => '7',
            8 => '8',
            9 => '9',
            10 => '10',
            11 => '11',
            12 => '12',
            13 => '13',
            14 => '14',
            15 => '15',
            16 => '16',
            17 => '17',
            18 => '18',
            19 => '19',
            20 => '20',
            21 => '21',
            22 => '22',
            23 => '23',
            24 => '24',
            25 => '25',
            26 => '26',
            27 => '27',
            28 => '28',
            29 => '29',
            30 => '30',
        );
        $items_max = 30;

        $mform->addElement('select', 'config_items', get_string('config_items', 'theme_molab'), $items_range);
        $mform->setDefault('config_items', 5);

        for($i = 1; $i <= $items; $i++) {
            $mform->addElement('header', 'config_molab_item' . $i , get_string('config_item', 'theme_molab') .' '. $i);

            $options = array(
                'multiple' => false,
            );
            $mform->addElement('autocomplete', 'config_category' . $i, get_string('category'), $molabCourseCategories, $options);

            $mform->addElement('text', 'config_img' . $i, 'Category Icon ' . $i);
            if($i <= 5):
                $mform->setDefault('config_img' . $i, $CFG->wwwroot.'/theme/molab/pix/categories/categories-'.$i.'.webp');
            else:
                $mform->setDefault('config_img' . $i, $CFG->wwwroot.'/theme/molab/pix/categories/categories-1.webp');
            endif;
            $mform->setType('config_img' . $i, PARAM_TEXT);
        }
    }
}
