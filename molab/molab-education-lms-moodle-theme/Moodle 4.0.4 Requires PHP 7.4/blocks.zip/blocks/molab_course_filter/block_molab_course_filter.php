<?php
require_once($CFG->dirroot. '/course/renderer.php');
require_once($CFG->dirroot . '/theme/molab/inc/course_handler/molab_course_handler.php');
require_once($CFG->dirroot . '/theme/molab/inc/block_handler/get-content.php');
global $CFG;
class block_molab_course_filter extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_molab_course_filter');
    }

    // Declare second
    public function specialization()
    {
        global $CFG, $DB;
        include($CFG->dirroot . '/theme/molab/inc/block_handler/specialization.php');
        if (empty($this->config)) {
            $this->config = new \stdClass();
            $this->config->class = 'popular-courses-area pb-100';
            $this->config->title = 'Popular Courses';
            $this->config->total_student_title = 'Students';
            $this->config->body = 'Enjoy the top notch learning methods and achieve next level skills! You are the creator of your own career &amp; we will guide you through that. <a href="#">Register Free Now!</a>';
            $this->config->style = 1;
        }
    }

    public function get_content() {
        global $CFG, $DB, $COURSE, $USER, $PAGE;

        if ($this->content !== null) {
            return $this->content;
        }

        $this->content         =  new stdClass;
        if(!empty($this->config->title)){$this->content->title = $this->config->title;} else {$this->content->title = '';}

        if(!empty($this->config->total_student_title)){$this->content->total_student_title = $this->config->total_student_title;} else {$this->content->total_student_title = '';}

        if(!empty($this->config->class)){$this->content->class = $this->config->class;} else {$this->content->class = '';} 

        if(!empty($this->config->body)){$this->content->body = $this->config->body;} else {$this->content->body = '';}

        $categories = array();
        if(!empty($this->config->courses)){
            $coursesArr = $this->config->courses;
            $courses = new stdClass();
            foreach ($coursesArr as $key => $course) {
                $courseObj = new stdClass();
                $courseObj->id = $course;
                $courseRecord = $DB->get_record('course', array('id' => $courseObj->id), 'category');
                $courseCategory = $DB->get_record('course_categories',array('id' => $courseRecord->category));
                $courseCategory = core_course_category::get($courseCategory->id);
                $courseObj->category = $courseCategory->id;
                $courseObj->category_name = $courseCategory->get_formatted_name();
                $courses->$course = $courseObj;
            }
            $categories = array();
            foreach ($courses as $key => $course) {
                $categories[$course->category] = $course->category_name;
            }
            $categories = array_unique($categories);
        }
        $style = 1;
        if(isset($this->config->style)){
            $style = $this->config->style;
        }
        $text = '';

        if($style == 2):
            $text .= '
            <div class="'.$this->content->class.'">
                <div class="container">
                    <div class="section-title ">
                        <h2>'.$this->content->title.'</h2>
                    </div>

                    <div class="row justify-content-center">';
                        if(!empty($this->config->courses)){
                            $chelper = new coursecat_helper();
                            $total_courses = count($coursesArr);
                            foreach ($courses as $course) {
                                if ($DB->record_exists('course', array('id' => $course->id))) {
                                    $molabCourseHandler = new molabCourseHandler();
                                    $molabCourse = $molabCourseHandler->molabGetCourseDetails($course->id);

                                    // Get Teacher Name
                                    foreach($molabCourse->teachers as $teacher):
                                        $teacher = $teacher->name;
                                    endforeach;

                                    $molabCourseDescription = strip_tags($molabCourseHandler->molabGetCourseDescription($course->id, 99999999999999));
                                    $molabCourseDescription = implode(' ', array_slice(str_word_count($molabCourseDescription, 2), 0, 15));
                                    $text .= '
                                    
                                    <div class="col-xl-4 col-sm-6">
                                        <div class="single-course-item style-three">
                                            <a href="'. $molabCourse->url .'" class="courses-img">
                                            '.$molabCourse->molabRender->coverImage.'';

                                                if($molabCourse->course_price) {
                                                    $text .= '
                                                    <span class="price">'.get_config('theme_molab', 'site_currency') .''.$molabCourse->course_price.'</span>';
                                                }else{
                                                    $text .= '
                                                    <span class="price">'.get_config('theme_molab', 'free_course_price') .'</span>';
                                                } $text .= '
                                            </a>

                                            <div class="courses-content">
                                                <h3>
                                                    <a href="'. $molabCourse->url .'">'.$molabCourse->fullName.'</a>
                                                </h3>

                                                <ul class="status d-flex align-items-center">
                                                    <li>
                                                        <i class="ri-time-line"></i>
                                                        '. $molabCourse->molabRender->updatedDate .'
                                                    </li>
                                                    <li>
                                                        <i class="ri-group-line"></i>
                                                        '.$molabCourse->enrolments.' '.$this->content->total_student_title.'
                                                    </li>
                                                </ul>

                                                <ul class="author d-flex justify-content-between align-items-center">
                                                    <li>
                                                        <a href="'. $molabCourse->url .'">
                                                            '.$teacher.'
                                                        </a>
                                                    </li>';
                                                    if(get_config('theme_molab', 'course_button_text')):
                                                        $text .= '
                                                        <li class="cart-btn">
                                                            <a href="'. $molabCourse->url .'" class="add-btn">
                                                                <i class="ri-book-open-line"></i>
                                                                <span>
                                                                '.get_config('theme_molab', 'course_button_text') .'
                                                                </span>
                                                            </a>
                                                        </li>';
                                                    endif;
                                                    $text .= '
                                                </ul>
                                            </div>
                                        </div>
                                    </div>';
                                }
                            }
                        }
                        $text .= '

                        <div class="col-12">
                            <div class="register-free">
                                <p>'.$this->content->body.'</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        else:
            $text .= '
            <div class="'.$this->content->class.'">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="section-title left-title">
                                <h2>'.$this->content->title.'</h2>
                            </div>
                        </div>
                    </div>

                    <div class="row justify-content-center">';
                        if(!empty($this->config->courses)){
                            $chelper = new coursecat_helper();
                            $total_courses = count($coursesArr);
                            foreach ($courses as $course) {
                                if ($DB->record_exists('course', array('id' => $course->id))) {
                                    $molabCourseHandler = new molabCourseHandler();
                                    $molabCourse = $molabCourseHandler->molabGetCourseDetails($course->id);

                                    // Get Teacher Name
                                    foreach($molabCourse->teachers as $teacher):
                                        $teacher = $teacher->name;
                                    endforeach;

                                    $molabCourseDescription = strip_tags($molabCourseHandler->molabGetCourseDescription($course->id, 99999999999999));
                                    $molabCourseDescription = implode(' ', array_slice(str_word_count($molabCourseDescription, 2), 0, 15));
                                    $text .= '
                                    
                                    <div class="col-xl-3 col-sm-6">
                                        <div class="single-course-item">
                                            <a href="'. $molabCourse->url .'" class="courses-img">
                                            '.$molabCourse->molabRender->coverImage.'';

                                                if($molabCourse->course_price) {
                                                    $text .= '
                                                    <span class="price">'.get_config('theme_molab', 'site_currency') .''.$molabCourse->course_price.'</span>';
                                                }else{
                                                    $text .= '
                                                    <span class="price">'.get_config('theme_molab', 'free_course_price') .'</span>';
                                                } $text .= '
                                            </a>

                                            <div class="courses-content">
                                                <h3>
                                                    <a href="'. $molabCourse->url .'">'.$molabCourse->fullName.'</a>
                                                </h3>

                                                <ul class="status d-flex align-items-center">
                                                    <li>
                                                        <i class="ri-time-line"></i>
                                                        '. $molabCourse->molabRender->updatedDate .'
                                                    </li>
                                                    <li>
                                                        <i class="ri-group-line"></i>
                                                        '.$molabCourse->enrolments.' '.$this->content->total_student_title.'
                                                    </li>
                                                </ul>

                                                <ul class="author d-flex justify-content-between align-items-center">
                                                    <li>
                                                        <a href="'. $molabCourse->url .'">
                                                            '.$teacher.'
                                                        </a>
                                                    </li>';
                                                    if(get_config('theme_molab', 'course_button_text')):
                                                        $text .= '
                                                        <li class="cart-btn">
                                                            <a href="'. $molabCourse->url .'" class="add-btn">
                                                                <i class="ri-book-open-line"></i>
                                                                <span>
                                                                '.get_config('theme_molab', 'course_button_text') .'
                                                                </span>
                                                            </a>
                                                        </li>';
                                                    endif;
                                                    $text .= '
                                                </ul>
                                            </div>
                                        </div>
                                    </div>';
                                }
                            }
                        }
                        $text .= '

                        <div class="col-12">
                            <div class="register-free">
                                <p>'.$this->content->body.'</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        endif;

        $this->content->footer = '';
        $this->content->text   = $text;

        return $this->content;
    }

    /**
     * The block can be used repeatmolab in a page.
     */
    function instance_allow_multiple() {
        return true;
    }

    /**
     * Enables global configuration of the block in settings.php.
     *
     * @return bool True if the global configuration is enabled.
     */
    function has_config() {
        return false;
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    function applicable_formats() {
        return array(
            'all' => true,
            'my' => false,
            'admin' => false,
            'course-view' => true,
            'course' => true,
        );
    }

}